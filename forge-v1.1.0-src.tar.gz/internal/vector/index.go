package vector

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"

	"github.com/forge/sword/internal/hnsw"
)

// Document represents a searchable document
type Document struct {
	ID       string                 `json:"id"`
	Content  string                 `json:"content"`
	Metadata map[string]string      `json:"metadata,omitempty"`
}

// SearchResult is a search hit
type SearchResult struct {
	Document Document  `json:"document"`
	Score    float32   `json:"score"`
}

// Index is a vector search index over documents
type Index struct {
	graph   *hnsw.Graph[string]
	docs    map[string]Document
	dim     int
	mu      sync.RWMutex
	path    string
}

// NewIndex creates a new vector search index
func NewIndex(dimension int, path string) *Index {
	return &Index{
		graph: hnsw.NewGraph[string](hnsw.WithM(16), hnsw.WithEf(100)),
		docs:  make(map[string]Document),
		dim:   dimension,
		path:  path,
	}
}

// LoadIndex loads an existing index from disk
func LoadIndex(path string) (*Index, error) {
	data, err := os.ReadFile(filepath.Join(path, "index.json"))
	if err != nil {
		return nil, fmt.Errorf("failed to load index: %w", err)
	}

	var store struct {
		Docs map[string]Document `json:"docs"`
		Dim  int                 `json:"dimension"`
	}
	if err := json.Unmarshal(data, &store); err != nil {
		return nil, fmt.Errorf("failed to parse index: %w", err)
	}

	idx := NewIndex(store.Dim, path)
	idx.docs = store.Docs

	// Rebuild the HNSW graph
	for id, doc := range store.Docs {
		// We don't have the vectors stored — need to re-embed
		// For now, documents are stored but graph needs re-build via Insert
		_ = id
		_ = doc
	}

	return idx, nil
}

// Insert adds a document with its embedding vector
func (idx *Index) Insert(doc Document, vector []float32) error {
	if len(vector) != idx.dim {
		return fmt.Errorf("vector dimension %d doesn't match index dimension %d", len(vector), idx.dim)
	}

	idx.mu.Lock()
	defer idx.mu.Unlock()

	idx.graph.Add(hnsw.MakeNode(doc.ID, vector))
	idx.docs[doc.ID] = doc
	return nil
}

// Search finds the k nearest neighbors to the query vector
func (idx *Index) Search(queryVector []float32, k int) ([]SearchResult, error) {
	idx.mu.RLock()
	defer idx.mu.RUnlock()

	nodes := idx.graph.Search(queryVector, k)

	results := make([]SearchResult, 0, len(nodes))
	for _, node := range nodes {
		doc, ok := idx.docs[node.Key]
		if !ok {
			continue
		}
		results = append(results, SearchResult{
			Document: doc,
			Score:    node.Distance,
		})
	}

	return results, nil
}

// Save persists the index to disk
func (idx *Index) Save() error {
	idx.mu.RLock()
	defer idx.mu.RUnlock()

	if idx.path == "" {
		return fmt.Errorf("no path set for index")
	}

	os.MkdirAll(idx.path, 0o755)

	store := struct {
		Docs map[string]Document `json:"docs"`
		Dim  int                 `json:"dimension"`
	}{
		Docs: idx.docs,
		Dim:  idx.dim,
	}

	data, err := json.MarshalIndent(store, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal index: %w", err)
	}

	return os.WriteFile(filepath.Join(idx.path, "index.json"), data, 0o644)
}

// Size returns the number of documents in the index
func (idx *Index) Size() int {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	return len(idx.docs)
}

// BulkInsert adds multiple documents
func (idx *Index) BulkInsert(docs []Document, vectors [][]float32) error {
	for i, doc := range docs {
		if i >= len(vectors) {
			break
		}
		if err := idx.Insert(doc, vectors[i]); err != nil {
			return fmt.Errorf("failed to insert doc %s: %w", doc.ID, err)
		}
	}
	return nil
}
