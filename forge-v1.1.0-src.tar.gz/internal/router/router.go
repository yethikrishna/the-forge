package router

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

type Provider string

const (
	ProviderAnthropic Provider = "anthropic"
	ProviderOpenAI    Provider = "openai"
	ProviderGoogle    Provider = "google"
	ProviderXAI       Provider = "xai"
)

type ModelConfig struct {
	Provider Provider
	ModelID  string
}

type Message struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type ChatRequest struct {
	Model    string    `json:"model"`
	Messages []Message `json:"messages"`
	Stream   bool      `json:"stream"`
}

type ChatResponse struct {
	Content string `json:"content"`
	Model   string `json:"model"`
	Usage   Usage  `json:"usage"`
}

type Usage struct {
	PromptTokens     int `json:"prompt_tokens"`
	CompletionTokens int `json:"completion_tokens"`
	TotalTokens      int `json:"total_tokens"`
}

type StreamChunk struct {
	Delta string `json:"delta,omitempty"`
	Done  bool   `json:"done"`
	Model string `json:"model"`
}

type ProviderClient struct {
	Provider Provider
	APIKey   string
	BaseURL  string
	Client   *http.Client
}

type ModelRouter struct {
	providers map[Provider]*ProviderClient
	mu        sync.RWMutex
}

func NewModelRouter() *ModelRouter {
	return &ModelRouter{providers: make(map[Provider]*ProviderClient)}
}

func (r *ModelRouter) RegisterProvider(provider Provider, apiKey, baseURL string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if baseURL == "" {
		switch provider {
		case ProviderAnthropic:
			baseURL = "https://api.anthropic.com"
		case ProviderOpenAI:
			baseURL = "https://api.openai.com"
		case ProviderGoogle:
			baseURL = "https://generativelanguage.googleapis.com"
		case ProviderXAI:
			baseURL = "https://api.x.ai"
		}
	}
	r.providers[provider] = &ProviderClient{Provider: provider, APIKey: apiKey, BaseURL: baseURL, Client: &http.Client{Timeout: 120 * time.Second}}
}

func ParseModel(modelStr string) (*ModelConfig, error) {
	parts := strings.SplitN(modelStr, "/", 2)
	if len(parts) != 2 {
		return nil, fmt.Errorf("model must be in provider/model format, got: %s", modelStr)
	}
	p := Provider(parts[0])
	if p != ProviderAnthropic && p != ProviderOpenAI && p != ProviderGoogle && p != ProviderXAI {
		return nil, fmt.Errorf("unknown provider: %s", parts[0])
	}
	return &ModelConfig{Provider: p, ModelID: parts[1]}, nil
}

func (r *ModelRouter) Chat(ctx context.Context, req ChatRequest) (*ChatResponse, error) {
	cfg, err := ParseModel(req.Model)
	if err != nil {
		return nil, err
	}
	r.mu.RLock()
	client, ok := r.providers[cfg.Provider]
	r.mu.RUnlock()
	if !ok {
		return nil, fmt.Errorf("provider %s not registered", cfg.Provider)
	}
	switch cfg.Provider {
	case ProviderAnthropic:
		return client.chatAnthropic(ctx, cfg, req)
	default:
		return client.chatOpenAICompat(ctx, cfg, req)
	}
}

func (r *ModelRouter) ChatStream(ctx context.Context, req ChatRequest) (<-chan StreamChunk, error) {
	cfg, err := ParseModel(req.Model)
	if err != nil {
		return nil, err
	}
	r.mu.RLock()
	client, ok := r.providers[cfg.Provider]
	r.mu.RUnlock()
	if !ok {
		return nil, fmt.Errorf("provider %s not registered", cfg.Provider)
	}
	req.Stream = true
	switch cfg.Provider {
	case ProviderAnthropic:
		return client.streamAnthropic(ctx, cfg, req)
	default:
		return client.streamOpenAICompat(ctx, cfg, req)
	}
}

func (r *ModelRouter) AutoRegister() int {
	count := 0
	for provider, key := range map[Provider]string{
		ProviderAnthropic: "ANTHROPIC_API_KEY",
		ProviderOpenAI:    "OPENAI_API_KEY",
		ProviderGoogle:    "GOOGLE_API_KEY",
		ProviderXAI:       "XAI_API_KEY",
	} {
		if v := strings.TrimSpace(os.Getenv(key)); v != "" {
			r.RegisterProvider(provider, v, "")
			count++
		}
	}
	return count
}

// --- Anthropic ---

func (c *ProviderClient) chatAnthropic(ctx context.Context, cfg *ModelConfig, req ChatRequest) (*ChatResponse, error) {
	payload := map[string]any{"model": cfg.ModelID, "max_tokens": 4096, "messages": req.Messages}
	body, _ := json.Marshal(payload)
	httpReq, _ := http.NewRequestWithContext(ctx, "POST", c.BaseURL+"/v1/messages", strings.NewReader(string(body)))
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("x-api-key", c.APIKey)
	httpReq.Header.Set("anthropic-version", "2023-06-01")

	resp, err := c.Client.Do(httpReq)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("anthropic %d: %s", resp.StatusCode, b)
	}

	var result struct {
		Content []struct{ Text string `json:"text"` } `json:"content"`
		Model   string `json:"model"`
		Usage   struct {
			InputTokens  int `json:"input_tokens"`
			OutputTokens int `json:"output_tokens"`
		} `json:"usage"`
	}
	json.NewDecoder(resp.Body).Decode(&result)
	content := ""
	if len(result.Content) > 0 {
		content = result.Content[0].Text
	}
	return &ChatResponse{Content: content, Model: result.Model, Usage: Usage{PromptTokens: result.Usage.InputTokens, CompletionTokens: result.Usage.OutputTokens, TotalTokens: result.Usage.InputTokens + result.Usage.OutputTokens}}, nil
}

func (c *ProviderClient) streamAnthropic(ctx context.Context, cfg *ModelConfig, req ChatRequest) (<-chan StreamChunk, error) {
	ch := make(chan StreamChunk, 100)
	payload := map[string]any{"model": cfg.ModelID, "max_tokens": 4096, "stream": true, "messages": req.Messages}
	body, _ := json.Marshal(payload)
	httpReq, _ := http.NewRequestWithContext(ctx, "POST", c.BaseURL+"/v1/messages", strings.NewReader(string(body)))
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("x-api-key", c.APIKey)
	httpReq.Header.Set("anthropic-version", "2023-06-01")

	resp, err := c.Client.Do(httpReq)
	if err != nil {
		close(ch)
		return nil, err
	}

	go func() {
		defer close(ch)
		defer resp.Body.Close()
		scanner := bufio.NewScanner(resp.Body)
		for scanner.Scan() {
			line := scanner.Text()
			if !strings.HasPrefix(line, "data: ") {
				continue
			}
			var event struct {
				Type  string `json:"type"`
				Delta struct{ Text string `json:"text"` } `json:"delta"`
			}
			json.Unmarshal([]byte(line[6:]), &event)
			if event.Type == "content_block_delta" {
				ch <- StreamChunk{Delta: event.Delta.Text, Model: cfg.ModelID}
			} else if event.Type == "message_stop" {
				ch <- StreamChunk{Done: true, Model: cfg.ModelID}
				return
			}
		}
		ch <- StreamChunk{Done: true}
	}()
	return ch, nil
}

// --- OpenAI-compatible (OpenAI, xAI, Google) ---

func (c *ProviderClient) chatOpenAICompat(ctx context.Context, cfg *ModelConfig, req ChatRequest) (*ChatResponse, error) {
	// Google has a different API
	if cfg.Provider == ProviderGoogle {
		return c.chatGoogle(ctx, cfg, req)
	}

	payload := map[string]any{"model": cfg.ModelID, "messages": req.Messages}
	body, _ := json.Marshal(payload)
	httpReq, _ := http.NewRequestWithContext(ctx, "POST", c.BaseURL+"/v1/chat/completions", strings.NewReader(string(body)))
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Authorization", "Bearer "+c.APIKey)

	resp, err := c.Client.Do(httpReq)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("%s %d: %s", cfg.Provider, resp.StatusCode, b)
	}

	var result struct {
		Choices []struct{ Message struct{ Content string `json:"content"` } } `json:"choices"`
		Model   string `json:"model"`
		Usage   Usage  `json:"usage"`
	}
	json.NewDecoder(resp.Body).Decode(&result)
	content := ""
	if len(result.Choices) > 0 {
		content = result.Choices[0].Message.Content
	}
	return &ChatResponse{Content: content, Model: result.Model, Usage: result.Usage}, nil
}

func (c *ProviderClient) streamOpenAICompat(ctx context.Context, cfg *ModelConfig, req ChatRequest) (<-chan StreamChunk, error) {
	if cfg.Provider == ProviderGoogle {
		return c.streamGoogle(ctx, cfg, req)
	}

	ch := make(chan StreamChunk, 100)
	payload := map[string]any{"model": cfg.ModelID, "stream": true, "messages": req.Messages}
	body, _ := json.Marshal(payload)
	httpReq, _ := http.NewRequestWithContext(ctx, "POST", c.BaseURL+"/v1/chat/completions", strings.NewReader(string(body)))
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Authorization", "Bearer "+c.APIKey)

	resp, err := c.Client.Do(httpReq)
	if err != nil {
		close(ch)
		return nil, err
	}

	go func() {
		defer close(ch)
		defer resp.Body.Close()
		scanner := bufio.NewScanner(resp.Body)
		for scanner.Scan() {
			line := scanner.Text()
			if !strings.HasPrefix(line, "data: ") {
				continue
			}
			data := line[6:]
			if data == "[DONE]" {
				ch <- StreamChunk{Done: true, Model: cfg.ModelID}
				return
			}
			var event struct {
				Choices []struct{ Delta struct{ Content string `json:"content"` } } `json:"choices"`
				Model   string `json:"model"`
			}
			json.Unmarshal([]byte(data), &event)
			if len(event.Choices) > 0 && event.Choices[0].Delta.Content != "" {
				ch <- StreamChunk{Delta: event.Choices[0].Delta.Content, Model: event.Model}
			}
		}
		ch <- StreamChunk{Done: true}
	}()
	return ch, nil
}

// --- Google ---

func (c *ProviderClient) chatGoogle(ctx context.Context, cfg *ModelConfig, req ChatRequest) (*ChatResponse, error) {
	contents := make([]map[string]any, 0, len(req.Messages))
	for _, m := range req.Messages {
		role := "user"
		if m.Role == "assistant" {
			role = "model"
		}
		contents = append(contents, map[string]any{"role": role, "parts": []map[string]any{{"text": m.Content}}})
	}
	payload := map[string]any{"contents": contents}
	body, _ := json.Marshal(payload)
	url := fmt.Sprintf("%s/v1beta/models/%s:generateContent?key=%s", c.BaseURL, cfg.ModelID, c.APIKey)
	httpReq, _ := http.NewRequestWithContext(ctx, "POST", url, strings.NewReader(string(body)))
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.Client.Do(httpReq)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("google %d: %s", resp.StatusCode, b)
	}

	var result struct {
		Candidates []struct{ Content struct{ Parts []struct{ Text string `json:"text"` } } } `json:"candidates"`
		UsageMetadata struct{ PromptTokenCount, CandidatesTokenCount, TotalTokenCount int } `json:"usageMetadata"`
	}
	json.NewDecoder(resp.Body).Decode(&result)
	content := ""
	if len(result.Candidates) > 0 && len(result.Candidates[0].Content.Parts) > 0 {
		content = result.Candidates[0].Content.Parts[0].Text
	}
	return &ChatResponse{Content: content, Model: cfg.ModelID, Usage: Usage{PromptTokens: result.UsageMetadata.PromptTokenCount, CompletionTokens: result.UsageMetadata.CandidatesTokenCount, TotalTokens: result.UsageMetadata.TotalTokenCount}}, nil
}

func (c *ProviderClient) streamGoogle(ctx context.Context, cfg *ModelConfig, req ChatRequest) (<-chan StreamChunk, error) {
	ch := make(chan StreamChunk, 100)
	contents := make([]map[string]any, 0, len(req.Messages))
	for _, m := range req.Messages {
		role := "user"
		if m.Role == "assistant" {
			role = "model"
		}
		contents = append(contents, map[string]any{"role": role, "parts": []map[string]any{{"text": m.Content}}})
	}
	payload := map[string]any{"contents": contents}
	body, _ := json.Marshal(payload)
	url := fmt.Sprintf("%s/v1beta/models/%s:streamGenerateContent?alt=sse&key=%s", c.BaseURL, cfg.ModelID, c.APIKey)
	httpReq, _ := http.NewRequestWithContext(ctx, "POST", url, strings.NewReader(string(body)))
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.Client.Do(httpReq)
	if err != nil {
		close(ch)
		return nil, err
	}

	go func() {
		defer close(ch)
		defer resp.Body.Close()
		scanner := bufio.NewScanner(resp.Body)
		for scanner.Scan() {
			line := scanner.Text()
			if !strings.HasPrefix(line, "data: ") {
				continue
			}
			var event struct{ Candidates []struct{ Content struct{ Parts []struct{ Text string `json:"text"` } } } }
			json.Unmarshal([]byte(line[6:]), &event)
			if len(event.Candidates) > 0 && len(event.Candidates[0].Content.Parts) > 0 && event.Candidates[0].Content.Parts[0].Text != "" {
				ch <- StreamChunk{Delta: event.Candidates[0].Content.Parts[0].Text, Model: cfg.ModelID}
			}
		}
		ch <- StreamChunk{Done: true}
	}()
	return ch, nil
}
