package cmd

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/spf13/cobra"
)

func initCmd() *cobra.Command {
	var name string

	cmd := &cobra.Command{
		Use:   "init [project-name]",
		Short: "Initialize a new Forge project with forge.json",
		Long: `Create a forge.json (Forgefile) in the current directory.
This defines your agent tasks, models, and dependencies.`,
		Args: cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			projectName := name
			if len(args) > 0 {
				projectName = args[0]
			}
			if projectName == "" {
				projectName = "my-project"
			}

			// Check if forge.json already exists
			if _, err := os.Stat("forge.json"); err == nil {
				return fmt.Errorf("forge.json already exists")
			}

			forge := map[string]interface{}{
				"name": projectName,
				"tasks": []map[string]interface{}{
					{
						"name":   "review",
						"agent":  "claude",
						"model":  "anthropic/claude-sonnet-4-20250514",
						"prompt": "Review the code for bugs and suggest improvements",
						"files":  []string{"*.go"},
						"jail":   true,
					},
					{
						"name":    "test",
						"agent":   "claude",
						"model":   "openai/gpt-5-mini",
						"prompt":  "Write unit tests for the reviewed code",
						"depends": []string{"review"},
					},
					{
						"name":    "commit",
						"prompt":  "Commit the changes with a descriptive message",
						"depends": []string{"test"},
					},
				},
			}

			data, err := json.MarshalIndent(forge, "", "  ")
			if err != nil {
				return fmt.Errorf("failed to generate forge.json: %w", err)
			}

			if err := os.WriteFile("forge.json", data, 0o644); err != nil {
				return fmt.Errorf("failed to write forge.json: %w", err)
			}

			fmt.Printf("Forge: Created forge.json for %q\n", projectName)
			fmt.Println()
			fmt.Println("  Tasks:")
			fmt.Println("    review  — Code review with Claude (jailed)")
			fmt.Println("    test    — Write tests with GPT-5-mini")
			fmt.Println("    commit  — AI-powered commit")
			fmt.Println()
			fmt.Println("  Run: forge run")
			fmt.Println("  List: forge run --list")
			return nil
		},
	}

	cmd.Flags().StringVarP(&name, "name", "n", "", "Project name")
	return cmd
}
