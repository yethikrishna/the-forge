package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/forge/sword/internal/router"
	"github.com/spf13/cobra"
)

func apiCmd() *cobra.Command {
	var port int
	var verbose bool

	cmd := &cobra.Command{
		Use:   "api",
		Short: "Start the Forge API server (unified LLM gateway)",
		Long: `Start an HTTP API server that provides a unified chat endpoint
for all LLM providers — no external proxy needed.

Endpoints:
  POST /v1/chat/completions  - OpenAI-compatible chat API
  POST /v1/messages          - Anthropic-compatible chat API
  GET  /v1/models            - List available models
  GET  /health               - Health check`,
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx, cancel := context.WithCancel(cmd.Context())
			defer cancel()

			mr := router.NewModelRouter()
			registered := mr.AutoRegister()
			if registered == 0 {
				return fmt.Errorf("no LLM API keys found in environment")
			}

			fmt.Printf("Forge API | Port: %d | Providers: %d\n", port, registered)

			mux := http.NewServeMux()

			// Health check
			mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(map[string]any{
					"status":    "ok",
					"providers": registered,
					"version":   forgeVersion,
				})
			})

			// List models
			mux.HandleFunc("/v1/models", func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				models := []map[string]string{
					{"id": "anthropic/claude-sonnet-4-20250514", "provider": "anthropic"},
					{"id": "anthropic/claude-opus-4-20250514", "provider": "anthropic"},
					{"id": "openai/gpt-5-mini", "provider": "openai"},
					{"id": "openai/o3", "provider": "openai"},
					{"id": "google/gemini-2.5-pro", "provider": "google"},
					{"id": "xai/grok-4-1-fast", "provider": "xai"},
				}
				json.NewEncoder(w).Encode(map[string]any{
					"object": "list",
					"data":   models,
				})
			})

			// OpenAI-compatible chat completions
			mux.HandleFunc("/v1/chat/completions", func(w http.ResponseWriter, r *http.Request) {
				if r.Method != "POST" {
					http.Error(w, "POST only", http.StatusMethodNotAllowed)
					return
				}

				var req struct {
					Model    string `json:"model"`
					Messages []struct {
						Role    string `json:"role"`
						Content string `json:"content"`
					} `json:"messages"`
					Stream bool `json:"stream"`
				}
				if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
					http.Error(w, err.Error(), http.StatusBadRequest)
					return
				}

				// Convert messages
				msgs := make([]router.Message, len(req.Messages))
				for i, m := range req.Messages {
					msgs[i] = router.Message{Role: m.Role, Content: m.Content}
				}

				if req.Stream {
					// SSE streaming
					w.Header().Set("Content-Type", "text/event-stream")
					w.Header().Set("Cache-Control", "no-cache")
					w.Header().Set("Connection", "keep-alive")

					ch, err := mr.ChatStream(r.Context(), router.ChatRequest{
						Model:    req.Model,
						Messages: msgs,
						Stream:   true,
					})
					if err != nil {
						fmt.Fprintf(w, "data: {\"error\":\"%s\"}\n\n", err.Error())
						return
					}

					flusher, _ := w.(http.Flusher)
					for chunk := range ch {
						if chunk.Done {
							fmt.Fprintf(w, "data: [DONE]\n\n")
							flusher.Flush()
							break
						}
						data, _ := json.Marshal(map[string]any{
							"choices": []map[string]any{
								{
									"delta": map[string]string{"content": chunk.Delta},
								},
							},
							"model": chunk.Model,
						})
						fmt.Fprintf(w, "data: %s\n\n", data)
						flusher.Flush()
					}
					return
				}

				// Non-streaming
				resp, err := mr.Chat(r.Context(), router.ChatRequest{
					Model:    req.Model,
					Messages: msgs,
				})
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}

				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(map[string]any{
					"id":      "forge-" + time.Now().Format("20060102150405"),
					"object":  "chat.completion",
					"model":   resp.Model,
					"choices": []map[string]any{
						{
							"index": 0,
							"message": map[string]string{
								"role":    "assistant",
								"content": resp.Content,
							},
						},
					},
					"usage": resp.Usage,
				})
			})

			// Anthropic-compatible messages API
			mux.HandleFunc("/v1/messages", func(w http.ResponseWriter, r *http.Request) {
				if r.Method != "POST" {
					http.Error(w, "POST only", http.StatusMethodNotAllowed)
					return
				}

				var req struct {
					Model     string `json:"model"`
					MaxTokens int    `json:"max_tokens"`
					Stream    bool   `json:"stream"`
					Messages  []struct {
						Role    string `json:"role"`
						Content string `json:"content"`
					} `json:"messages"`
				}
				if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
					http.Error(w, err.Error(), http.StatusBadRequest)
					return
				}

				msgs := make([]router.Message, len(req.Messages))
				for i, m := range req.Messages {
					msgs[i] = router.Message{Role: m.Role, Content: m.Content}
				}

				if req.Stream {
					w.Header().Set("Content-Type", "text/event-stream")
					w.Header().Set("Cache-Control", "no-cache")
					w.Header().Set("Connection", "keep-alive")

					ch, err := mr.ChatStream(r.Context(), router.ChatRequest{
						Model:    req.Model,
						Messages: msgs,
						Stream:   true,
					})
					if err != nil {
						fmt.Fprintf(w, "event: error\ndata: {\"error\":\"%s\"}\n\n", err.Error())
						return
					}

					flusher, _ := w.(http.Flusher)
					for chunk := range ch {
						if chunk.Done {
							fmt.Fprintf(w, "event: message_stop\ndata: {}\n\n")
							flusher.Flush()
							break
						}
						data, _ := json.Marshal(map[string]any{
							"type": "content_block_delta",
							"delta": map[string]string{
								"type": "text_delta",
								"text": chunk.Delta,
							},
						})
						fmt.Fprintf(w, "event: content_block_delta\ndata: %s\n\n", data)
						flusher.Flush()
					}
					return
				}

				resp, err := mr.Chat(r.Context(), router.ChatRequest{
					Model:    req.Model,
					Messages: msgs,
				})
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}

				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(map[string]any{
					"id":      "forge-" + time.Now().Format("20060102150405"),
					"type":    "message",
					"role":    "assistant",
					"model":   resp.Model,
					"content": []map[string]any{{"type": "text", "text": resp.Content}},
					"usage": map[string]any{
						"input_tokens":  resp.Usage.PromptTokens,
						"output_tokens": resp.Usage.CompletionTokens,
					},
				})
			})

			server := &http.Server{Addr: fmt.Sprintf(":%d", port), Handler: mux}

			go func() {
				fmt.Printf("Forge API server on http://localhost:%d\n", port)
				fmt.Printf("  OpenAI:     POST http://localhost:%d/v1/chat/completions\n", port)
				fmt.Printf("  Anthropic:  POST http://localhost:%d/v1/messages\n", port)
				fmt.Printf("  Models:     GET  http://localhost:%d/v1/models\n", port)
				fmt.Printf("  Health:     GET  http://localhost:%d/health\n", port)
				if err := server.ListenAndServe(); err != http.ErrServerClosed {
					fmt.Printf("Forge: Server error: %v\n", err)
				}
			}()

			sigChan := make(chan os.Signal, 1)
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

			select {
			case <-sigChan:
				fmt.Println("\nForge: Shutting down...")
			case <-ctx.Done():
			}

			server.Shutdown(context.Background())
			return nil
		},
	}

	cmd.Flags().IntVarP(&port, "port", "p", 8080, "API server port")
	cmd.Flags().BoolVarP(&verbose, "verbose", "v", false, "Verbose logging")

	return cmd
}
