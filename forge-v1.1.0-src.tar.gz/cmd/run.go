package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"

	"github.com/spf13/cobra"
)

type ForgeTask struct {
	Name    string   `json:"name"`
	Agent   string   `json:"agent"`
	Model   string   `json:"model"`
	Prompt  string   `json:"prompt"`
	Files   []string `json:"files"`
	Depends []string `json:"depends"`
	Jail    bool     `json:"jail"`
	Timeout int      `json:"timeout"`
}

func runTaskCmd() *cobra.Command {
	var forgefile string
	var listOnly bool

	cmd := &cobra.Command{
		Use:   "run [task]",
		Short: "Run agent tasks from a Forgefile (Makefile for AI agents)",
		Long: `Execute agent tasks defined in a Forgefile.

A Forgefile defines tasks combining agents, models, prompts, and files.
Tasks can depend on each other and run in dependency order.

Example forge.json:
  {
    "tasks": [
      {"name": "review", "agent": "claude", "model": "anthropic/claude-sonnet-4-20250514",
       "prompt": "Review this code for bugs", "files": ["src/main.go"], "jail": true},
      {"name": "test", "agent": "claude", "model": "openai/gpt-5-mini",
       "prompt": "Write unit tests", "depends": ["review"]},
      {"name": "commit", "prompt": "Commit the changes", "depends": ["test"]}
    ]
  }

Usage:
  forge run              # Run all tasks
  forge run review       # Run specific task and its deps
  forge run --list       # List available tasks`,
		Args: cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx, cancel := context.WithCancel(cmd.Context())
			defer cancel()
			sigChan := make(chan os.Signal, 1)
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
			go func() { <-sigChan; cancel() }()

			ffPath := forgefile
			if ffPath == "" {
				for _, c := range []string{"forge.json", "Forgefile", "Forgefile.json", ".forge.json"} {
					if _, err := os.Stat(c); err == nil {
						ffPath = c
						break
					}
				}
			}
			if ffPath == "" {
				return fmt.Errorf("no Forgefile found. Create forge.json or use -f")
			}

			data, err := os.ReadFile(ffPath)
			if err != nil {
				return fmt.Errorf("read %s: %w", ffPath, err)
			}

			var forge struct {
				Tasks []ForgeTask `json:"tasks"`
			}
			if err := json.Unmarshal(data, &forge); err != nil {
				return fmt.Errorf("parse %s: %w", ffPath, err)
			}

			if len(forge.Tasks) == 0 {
				return fmt.Errorf("no tasks in %s", ffPath)
			}

			if listOnly {
				fmt.Printf("Forge: Tasks in %s\n\n", ffPath)
				for _, t := range forge.Tasks {
					jail := ""
					if t.Jail {
						jail = " [jailed]"
					}
					deps := ""
					if len(t.Depends) > 0 {
						deps = fmt.Sprintf(" after %s", strings.Join(t.Depends, ","))
					}
					fmt.Printf("  %-15s %s/%s%s%s\n", t.Name, t.Agent, t.Model, deps, jail)
					if t.Prompt != "" {
						fmt.Printf("    %s\n", truncateStr(t.Prompt, 80))
					}
				}
				return nil
			}

			targetTask := ""
			if len(args) > 0 {
				targetTask = args[0]
			}

			order, err := topoSort(forge.Tasks, targetTask)
			if err != nil {
				return err
			}

			fmt.Printf("Forge: Running %d tasks from %s\n\n", len(order), ffPath)

			for i, taskName := range order {
				select {
				case <-ctx.Done():
					return ctx.Err()
				default:
				}

				var task *ForgeTask
				for j := range forge.Tasks {
					if forge.Tasks[j].Name == taskName {
						task = &forge.Tasks[j]
						break
					}
				}
				if task == nil {
					continue
				}

				fmt.Printf("[%d/%d] %s — %s/%s\n", i+1, len(order), task.Name, task.Agent, task.Model)

				// Build prompt with file contents
				prompt := task.Prompt
				for _, f := range task.Files {
					content, err := os.ReadFile(f)
					if err != nil {
						fmt.Printf("  Warning: can't read %s\n", f)
						continue
					}
					rel, _ := filepath.Rel(".", f)
					prompt += fmt.Sprintf("\n\n--- %s ---\n%s", rel, string(content))
				}

				if task.Agent != "" && task.Agent != "direct" {
					fmt.Printf("  Agent: %s | Prompt: %s...\n", task.Agent, truncateStr(prompt, 60))
					// TODO: Full agentapi + router execution
					fmt.Printf("  (execution wired through forge serve)\n")
				} else {
					fmt.Printf("  Model: %s | Prompt: %s...\n", task.Model, truncateStr(prompt, 60))
					// TODO: Direct router execution
					fmt.Printf("  (direct model execution via forge chat)\n")
				}
			}

			fmt.Println("\nForge: All tasks complete.")
			return nil
		},
	}

	cmd.Flags().StringVarP(&forgefile, "forgefile", "f", "", "Path to Forgefile")
	cmd.Flags().BoolVarP(&listOnly, "list", "l", false, "List tasks without running")
	return cmd
}

func truncateStr(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

func topoSort(tasks []ForgeTask, target string) ([]string, error) {
	taskMap := make(map[string]*ForgeTask)
	for i := range tasks {
		taskMap[tasks[i].Name] = &tasks[i]
	}

	visited := make(map[string]bool)
	var order []string

	var visit func(string) error
	visit = func(name string) error {
		if visited[name] {
			return nil
		}
		visited[name] = true
		t, ok := taskMap[name]
		if !ok {
			return fmt.Errorf("task %q not found", name)
		}
		for _, dep := range t.Depends {
			if err := visit(dep); err != nil {
				return err
			}
		}
		order = append(order, name)
		return nil
	}

	if target != "" {
		return order, visit(target)
	}
	for _, t := range tasks {
		if err := visit(t.Name); err != nil {
			return nil, err
		}
	}
	return order, nil
}
