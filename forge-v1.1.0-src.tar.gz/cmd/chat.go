package cmd

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"os/signal"
	"strings"
	"syscall"

	"github.com/forge/sword/internal/router"
	"github.com/spf13/cobra"
)

func chatCmd() *cobra.Command {
	var model string
	var system string
	var stream bool

	cmd := &cobra.Command{
		Use:   "chat",
		Short: "Chat directly with any LLM through the Forge model router",
		Long: `Interactive chat with any LLM provider — no external proxy needed.
The Forge model router talks directly to Anthropic, OpenAI, Google, and xAI.

Examples:
  forge chat -m anthropic/claude-sonnet-4-20250514
  forge chat -m openai/gpt-5-mini
  forge chat -m google/gemini-2.5-pro -s "You are a helpful coding assistant"
  forge chat -m xai/grok-4-1-fast --no-stream`,
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx, cancel := context.WithCancel(cmd.Context())
			defer cancel()

			sigChan := make(chan os.Signal, 1)
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
			go func() {
				<-sigChan
				cancel()
			}()

			// Initialize model router
			mr := router.NewModelRouter()
			registered := mr.AutoRegister()
			if registered == 0 {
				return fmt.Errorf("no LLM API keys found in environment\nSet one of: ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_API_KEY, XAI_API_KEY")
			}

			fmt.Printf("Forge Chat | Model: %s | Providers: %d\n", model, registered)
			fmt.Println("Type your message (or /quit to exit, /model to switch)")
			fmt.Println()

			// Conversation history
			var messages []router.Message
			if system != "" {
				messages = append(messages, router.Message{Role: "user", Content: system})
				messages = append(messages, router.Message{Role: "assistant", Content: "Understood. I'll follow those instructions."})
			}

			scanner := bufio.NewScanner(os.Stdin)
			for {
				fmt.Print("You> ")
				if !scanner.Scan() {
					break
				}
				input := strings.TrimSpace(scanner.Text())
				if input == "" {
					continue
				}
				if input == "/quit" || input == "/exit" {
					fmt.Println("Forge: Goodbye.")
					break
				}
				if strings.HasPrefix(input, "/model ") {
					model = strings.TrimPrefix(input, "/model ")
					fmt.Printf("Switched to %s\n", model)
					continue
				}

				messages = append(messages, router.Message{Role: "user", Content: input})

				if stream {
					ch, err := mr.ChatStream(ctx, router.ChatRequest{
						Model:    model,
						Messages: messages,
						Stream:   true,
					})
					if err != nil {
						fmt.Printf("Error: %v\n", err)
						messages = messages[:len(messages)-1]
						continue
					}

					fmt.Print("AI>  ")
					var fullResponse strings.Builder
					for chunk := range ch {
						if chunk.Done {
							break
						}
						fmt.Print(chunk.Delta)
						fullResponse.WriteString(chunk.Delta)
					}
					fmt.Println()
					messages = append(messages, router.Message{Role: "assistant", Content: fullResponse.String()})
				} else {
					resp, err := mr.Chat(ctx, router.ChatRequest{
						Model:    model,
						Messages: messages,
					})
					if err != nil {
						fmt.Printf("Error: %v\n", err)
						messages = messages[:len(messages)-1]
						continue
					}

					fmt.Printf("AI>  %s\n", resp.Content)
					fmt.Printf("     [%s | %d tokens]\n", resp.Model, resp.Usage.TotalTokens)
					messages = append(messages, router.Message{Role: "assistant", Content: resp.Content})
				}

				select {
				case <-ctx.Done():
					fmt.Println("\nForge: Session ended.")
					return nil
				default:
				}
			}

			return nil
		},
	}

	cmd.Flags().StringVarP(&model, "model", "m", "anthropic/claude-sonnet-4-20250514", "Model (provider/model)")
	cmd.Flags().StringVarP(&system, "system", "s", "", "System prompt")
	cmd.Flags().BoolVarP(&stream, "stream", "", true, "Stream responses")

	return cmd
}
