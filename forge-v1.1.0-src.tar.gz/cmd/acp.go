package cmd

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/signal"
	"strings"
	"syscall"

	"github.com/spf13/cobra"
)

// ACP implements the Agent Client Protocol natively
// Based on github.com/coder/acp-go-sdk

type ACPRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      int             `json:"id,omitempty"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
}

type ACPResponse struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      int             `json:"id"`
	Result  json.RawMessage `json:"result,omitempty"`
	Error   *ACPError       `json:"error,omitempty"`
}

type ACPError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type ACPInitializeResult struct {
	ProtocolVersion string              `json:"protocolVersion"`
	Capabilities    ACPCapabilities     `json:"capabilities"`
	ServerInfo      ACPServerInfo       `json:"serverInfo"`
}

type ACPCapabilities struct {
	Commands   []string `json:"commands,omitempty"`
	Tools      bool     `json:"tools"`
	Sessions   bool     `json:"sessions"`
	Streaming  bool     `json:"streaming"`
}

type ACPServerInfo struct {
	Name    string `json:"name"`
	Version string `json:"version"`
}

type ACPSession struct {
	ID   string `json:"id"`
	Name string `json:"name,omitempty"`
}

type ACPPromptParams struct {
	SessionID string `json:"sessionId"`
	Message   string `json:"message"`
}

func acpCmd() *cobra.Command {
	var mode string
	var agentCmd string

	cmd := &cobra.Command{
		Use:   "acp",
		Short: "Agent Client Protocol server/client",
		Long: `Speak the Agent Client Protocol natively.

ACP is the open standard for editor ↔ agent communication.
Forge can act as either the agent side or client side.

Modes:
  agent  - Start as an ACP agent (stdin/stdout JSON-RPC)
  client - Start as an ACP client (connect to agent)
  proxy  - Bridge ACP ↔ HTTP (expose agent via HTTP API)`,
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx, cancel := context.WithCancel(cmd.Context())
			defer cancel()

			sigChan := make(chan os.Signal, 1)
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
			go func() { <-sigChan; cancel() }()

			switch mode {
			case "agent":
				return runACPAgent(ctx)
			case "client":
				return runACPClient(ctx)
			case "proxy":
				return runACPProxy(ctx)
			default:
				return fmt.Errorf("unknown mode %q (use: agent, client, proxy)", mode)
			}
		},
	}

	cmd.Flags().StringVarP(&mode, "mode", "m", "agent", "ACP mode (agent|client|proxy)")
	cmd.Flags().StringVarP(&agentCmd, "agent", "a", "", "Agent command to wrap (for proxy mode)")

	return cmd
}

func runACPAgent(ctx context.Context) error {
	fmt.Fprintf(os.Stderr, "Forge ACP: Agent mode (JSON-RPC on stdin/stdout)\n")
	fmt.Fprintf(os.Stderr, "Protocol version: 0.13.0\n")
	fmt.Fprintf(os.Stderr, "Capabilities: sessions, streaming, tools\n\n")

	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		select {
		case <-ctx.Done():
			return nil
		default:
		}

		line := scanner.Text()
		if line == "" {
			continue
		}

		var req ACPRequest
		if err := json.Unmarshal([]byte(line), &req); err != nil {
			sendACPError(0, -32700, "Parse error")
			continue
		}

		resp := handleACPRequest(req)
		data, _ := json.Marshal(resp)
		fmt.Println(string(data))
	}
	return nil
}

func handleACPRequest(req ACPRequest) ACPResponse {
	switch req.Method {
	case "initialize":
		result, _ := json.Marshal(ACPInitializeResult{
			ProtocolVersion: "0.13.0",
			Capabilities: ACPCapabilities{
				Commands:  []string{"session/new", "session/load", "prompt", "cancel"},
				Tools:     true,
				Sessions:  true,
				Streaming: true,
			},
			ServerInfo: ACPServerInfo{
				Name:    "forge",
				Version: forgeVersion,
			},
		})
		return ACPResponse{JSONRPC: "2.0", ID: req.ID, Result: result}

	case "session/new":
		result, _ := json.Marshal(ACPSession{
			ID:   fmt.Sprintf("forge-%d", req.ID),
			Name: "forge-session",
		})
		return ACPResponse{JSONRPC: "2.0", ID: req.ID, Result: result}

	case "session/load":
		result, _ := json.Marshal(map[string]bool{"loaded": true})
		return ACPResponse{JSONRPC: "2.0", ID: req.ID, Result: result}

	case "prompt":
		var params ACPPromptParams
		if err := json.Unmarshal(req.Params, &params); err != nil {
			sendACPError(req.ID, -32602, "Invalid params")
			return ACPResponse{JSONRPC: "2.0", ID: req.ID}
		}
		// In real implementation, this would forward to the agent
		result, _ := json.Marshal(map[string]string{
			"status":  "processing",
			"message": fmt.Sprintf("Forge received: %s", params.Message),
		})
		return ACPResponse{JSONRPC: "2.0", ID: req.ID, Result: result}

	case "cancel":
		result, _ := json.Marshal(map[string]bool{"cancelled": true})
		return ACPResponse{JSONRPC: "2.0", ID: req.ID, Result: result}

	default:
		sendACPError(req.ID, -32601, fmt.Sprintf("Method not found: %s", req.Method))
		return ACPResponse{JSONRPC: "2.0", ID: req.ID}
	}
}

func sendACPError(id int, code int, message string) {
	resp := ACPResponse{
		JSONRPC: "2.0",
		ID:      id,
		Error:   &ACPError{Code: code, Message: message},
	}
	data, _ := json.Marshal(resp)
	fmt.Println(string(data))
}

func runACPClient(ctx context.Context) error {
	fmt.Fprintf(os.Stderr, "Forge ACP: Client mode\n")
	fmt.Fprintf(os.Stderr, "Connect to an ACP agent via stdin/stdout JSON-RPC\n")
	// TODO: Implement client mode
	return fmt.Errorf("client mode not yet implemented - use forge serve --acp instead")
}

func runACPProxy(ctx context.Context) error {
	fmt.Fprintf(os.Stderr, "Forge ACP: Proxy mode\n")
	fmt.Fprintf(os.Stderr, "Bridging ACP ↔ HTTP API\n")
	// TODO: Bridge ACP JSON-RPC to HTTP endpoints
	return fmt.Errorf("proxy mode not yet implemented - use forge serve --acp instead")
}

// ioCopy is unused but kept for future proxy implementation
var _ = io.Copy

// stringsReader is unused but kept for future use
var _ = strings.NewReader
