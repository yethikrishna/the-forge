package cmd

import (
	"fmt"
	"os"
	"os/exec"

	"github.com/spf13/cobra"
)

func envCmd() *cobra.Command {
	var dockerfile string
	var gitURL string
	var initScript string
	var runtime string

	cmd := &cobra.Command{
		Use:   "env",
		Short: "Build and manage dev environments (envbuilder)",
		Long: `Spin up development environments from Dockerfiles or devcontainer.json.
Uses envbuilder (github.com/coder/envbuilder) under the hood.

Supports Docker, Kubernetes, and OpenShift.
Caches image layers for fast rebuilds.`,
	}

	cmd.AddCommand(
		&cobra.Command{
			Use:   "build",
			Short: "Build a dev environment from Dockerfile",
			Long: `Build a development environment using envbuilder.
Requires Docker running on the system.`,
			RunE: func(cmd *cobra.Command, args []string) error {
				if dockerfile == "" && gitURL == "" {
					return fmt.Errorf("provide --dockerfile or --git-url")
				}

				envbuilderPath, err := exec.LookPath("envbuilder")
				if err != nil {
					return fmt.Errorf("envbuilder not found.\nInstall: go install github.com/coder/envbuilder@latest\nOr use Docker: docker run -it coder/envbuilder")
				}

				envArgs := []string{}
				if gitURL != "" {
					os.Setenv("ENVBUILDER_GIT_URL", gitURL)
				}
				if initScript != "" {
					os.Setenv("ENVBUILDER_INIT_SCRIPT", initScript)
				}

				envArgs = append(envArgs, "--dockerfile", dockerfile)

				fmt.Printf("Forge: Building environment...\n")
				fmt.Printf("  Dockerfile: %s\n", dockerfile)
				fmt.Printf("  Git URL:    %s\n", gitURL)
				fmt.Printf("  Init:       %s\n", initScript)

				proc := exec.Command(envbuilderPath, envArgs...)
				proc.Stdin = os.Stdin
				proc.Stdout = os.Stdout
				proc.Stderr = os.Stderr
				return proc.Run()
			},
		},
		&cobra.Command{
			Use:   "list",
			Short: "List running environments",
			RunE: func(cmd *cobra.Command, args []string) error {
				fmt.Println("Forge: Running environments:")
				fmt.Println("  (requires Docker - listing containers with forge label)")
				proc := exec.Command("docker", "ps", "--filter", "label=forge=true", "--format", "table {{.ID}}\t{{.Image}}\t{{.Status}}\t{{.Names}}")
				proc.Stdout = os.Stdout
				proc.Stderr = os.Stderr
				return proc.Run()
			},
		},
		&cobra.Command{
			Use:   "shell [container]",
			Short: "Shell into a running environment",
			Args:  cobra.ExactArgs(1),
			RunE: func(cmd *cobra.Command, args []string) error {
				proc := exec.Command("docker", "exec", "-it", args[0], "bash")
				proc.Stdin = os.Stdin
				proc.Stdout = os.Stdout
				proc.Stderr = os.Stderr
				return proc.Run()
			},
		},
	)

	cmd.Flags().StringVarP(&dockerfile, "dockerfile", "f", "Dockerfile", "Path to Dockerfile")
	cmd.Flags().StringVar(&gitURL, "git-url", "", "Git URL to clone and build")
	cmd.Flags().StringVar(&initScript, "init", "", "Init script to run after build")
	cmd.Flags().StringVar(&runtime, "runtime", "docker", "Container runtime (docker|kubernetes)")

	return cmd
}
