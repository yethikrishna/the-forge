package cmd

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/spf13/cobra"
)

func agentsmdCmd() *cobra.Command {
	var dir string

	cmd := &cobra.Command{
		Use:   "agentsmd",
		Short: "Parse and execute AGENTS.md instructions",
		Long: `Parse AGENTS.md files (the open format for guiding AI coding agents).

AGENTS.md is the open standard maintained by Anthropic and the community.
It defines how agents should behave in a codebase — build commands,
test commands, architecture notes, and coding guidelines.

Forge reads AGENTS.md to understand how to work with any project.`,
	}

	cmd.AddCommand(
		&cobra.Command{
			Use:   "parse [path]",
			Short: "Parse an AGENTS.md file and display its structure",
			Args:  cobra.MaximumNArgs(1),
			RunE: func(cmd *cobra.Command, args []string) error {
				searchDir := dir
				if len(args) > 0 {
					searchDir = args[0]
				}
				if searchDir == "" {
					searchDir = "."
				}

				// Find AGENTS.md files
				agentsFiles := []string{}
				filepath.Walk(searchDir, func(path string, info os.FileInfo, err error) error {
					if err != nil {
						return nil
					}
					if strings.EqualFold(info.Name(), "AGENTS.md") || strings.EqualFold(info.Name(), "CLAUDE.md") {
						agentsFiles = append(agentsFiles, path)
					}
					return nil
				})

				if len(agentsFiles) == 0 {
					return fmt.Errorf("no AGENTS.md or CLAUDE.md files found in %s", searchDir)
				}

				for _, f := range agentsFiles {
					data, err := os.ReadFile(f)
					if err != nil {
						continue
					}
					content := string(data)
					sections := parseAgentsMd(content)

					fmt.Printf("Forge: %s\n", f)
					fmt.Printf("  Sections: %d\n", len(sections))
					for _, s := range sections {
						fmt.Printf("  - %s (%d lines)\n", s.Title, s.LineCount)
					}
					fmt.Println()
				}

				return nil
			},
		},
		&cobra.Command{
			Use:   "run [path]",
			Short: "Execute build/test commands from AGENTS.md",
			Args:  cobra.MaximumNArgs(1),
			RunE: func(cmd *cobra.Command, args []string) error {
				searchDir := "."
				if len(args) > 0 {
					searchDir = args[0]
				}

				// Find and parse AGENTS.md
				agentsPath := filepath.Join(searchDir, "AGENTS.md")
				data, err := os.ReadFile(agentsPath)
				if err != nil {
					data, err = os.ReadFile(filepath.Join(searchDir, "CLAUDE.md"))
					if err != nil {
						return fmt.Errorf("no AGENTS.md found")
					}
				}

				sections := parseAgentsMd(string(data))
				fmt.Println("Forge: AGENTS.md commands:")
				for _, s := range sections {
					fmt.Printf("  %s:\n", s.Title)
					for _, line := range s.CodeBlocks {
						fmt.Printf("    $ %s\n", line)
					}
				}
				return nil
			},
		},
	)

	cmd.Flags().StringVarP(&dir, "dir", "d", ".", "Directory to search")

	return cmd
}

type Section struct {
	Title      string
	Content    string
	CodeBlocks []string
	LineCount  int
}

func parseAgentsMd(content string) []Section {
	var sections []Section
	var current *Section

	lines := strings.Split(content, "\n")
	inCodeBlock := false
	var codeLines []string

	for _, line := range lines {
		if strings.HasPrefix(line, "```") {
			if inCodeBlock {
				// End of code block
				if current != nil {
					current.CodeBlocks = append(current.CodeBlocks, strings.Join(codeLines, "\n"))
				}
				inCodeBlock = false
				codeLines = nil
			} else {
				inCodeBlock = true
				codeLines = nil
			}
			continue
		}

		if inCodeBlock {
			codeLines = append(codeLines, line)
			continue
		}

		if strings.HasPrefix(line, "#") {
			if current != nil {
				current.LineCount = len(strings.Split(current.Content, "\n"))
				sections = append(sections, *current)
			}
			title := strings.TrimSpace(strings.TrimLeft(line, "#"))
			current = &Section{Title: title, Content: line}
		} else if current != nil {
			current.Content += "\n" + line
		}
	}

	if current != nil {
		current.LineCount = len(strings.Split(current.Content, "\n"))
		sections = append(sections, *current)
	}

	return sections
}
