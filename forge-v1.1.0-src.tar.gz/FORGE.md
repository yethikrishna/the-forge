# THE FORGE v1.0 — Mythic Sword Specification

## The 31 Weapons Melted Into The Sword

| # | Weapon (Repo) | Language | What It Kills | Forged Into |
|---|--------------|----------|---------------|-------------|
| 1 | **coder** | Go | Infrastructure lock-in (Coder platform) | `forge infra` — Terraform-based workspace provisioning |
| 2 | **agentapi** | Go | Single-agent lock-in | `forge serve` — HTTP API for ANY agent |
| 3 | **acp-go-sdk** | Go | Proprietary editor protocols | `forge acp` — Native ACP server/client |
| 4 | **anyclaude** | TS | Model vendor lock-in | `internal/router` — Native multi-provider routing |
| 5 | **aisdk-go** | Go | Streaming protocol fragmentation | `internal/router` — Unified streaming (SSE + Data Stream) |
| 6 | **ai-tokenizer** | TS | Slow tokenization | Token counting for cost control |
| 7 | **aicommit** | Go | Manual git workflows | `forge commit` — AI-powered commits |
| 8 | **httpjail** | Rust | Untrusted agent execution | `forge jail` — Network sandboxing |
| 9 | **agent-tty** | TS | Black-box terminal automation | `forge tty` — Inspectable PTY sessions with snapshots |
| 10 | **blink** | TS | SaaS-only agent platforms | `forge blink` — Self-hosted agent platform (Slack/GitHub/Web) |
| 11 | **mux** | TS/Go | Single-agent dev workflows | `forge mux` — Parallel multi-agent desktop app |
| 12 | **code-server** | TS | Desktop-only IDEs | `forge ide` — VS Code in browser |
| 13 | **ghostty-web** | TS/WASM | Poor terminal rendering | `internal/term` — VT100 in browser via WASM |
| 14 | **hnsw** | Go | Keyword-only search | `internal/vector` — Semantic code search |
| 15 | **envbuilder** | Go | Slow environment setup | `forge env` — Build dev environments from Dockerfile |
| 16 | **envbox** | Go | Privileged containers | `internal/sandbox` — Non-privileged workspace containers |
| 17 | **wush** | Go | Insecure file transfer | `forge transfer` — P2P encrypted transfer |
| 18 | **guts** | Go | Dumb git operations | `internal/git` — AST-aware git operations |
| 19 | **quartz** | Go | Flaky time in tests | `internal/clock` — Deterministic time |
| 20 | **redjet** | Go | Slow Redis access | `internal/cache` — Pipeline-optimized caching |
| 21 | **slog** | Go | Unstructured logging | `internal/log` — Structured logging |
| 22 | **websocket** | Go | Unreliable real-time | `internal/ws` — Production WebSocket |
| 23 | **yamux** | Go | Connection bottleneck | `internal/mux` — Connection multiplexing |
| 24 | **kcp-go** | Go | TCP latency | `internal/kcp` — Reliable UDP transport |
| 25 | **go-reap** | Go | Zombie processes | `internal/reaper` — Child process management |
| 26 | **claudecode.nvim** | Lua | Editor lock-in | `forge neovim` — ACP in Neovim |
| 27 | **agents.md** | MD | Proprietary agent formats | `internal/agentsmd` — Open agent instruction parser |
| 28 | **agentskills** | MD | Closed skill systems | `internal/skills` — Open skill discovery/execution |
| 29 | **skills** | MD | (docs) | Skill specification |
| 30 | **code-marketplace** | TS | Extension silos | `forge marketplace` — Extension registry |
| 31 | **vscode-coder** | TS | IDE lock-in | `forge vscode` — VS Code integration |

## THE SINGLETON FORM

The old man and the sword are ONE. This means:

```
YOU (the developer)
  │
  ├── forge chat ─────── Talk to ANY model directly (no proxy)
  ├── forge serve ────── Run ANY agent with ACP/PTY
  ├── forge orchestrate ─ Run MANY agents in parallel
  ├── forge api ──────── Unified LLM gateway (OpenAI + Anthropic compatible)
  ├── forge mux ──────── Parallel agent desktop (like Cursor but open)
  ├── forge blink ────── Self-hosted agent platform (Slack/GitHub)
  ├── forge tty ──────── Inspectable terminal automation
  ├── forge jail ─────── Sandbox everything
  ├── forge env ──────── Spin up dev environments
  ├── forge ide ──────── VS Code in browser
  ├── forge search ───── Semantic code search
  ├── forge commit ───── AI git commits
  ├── forge transfer ─── P2P encrypted transfer
  ├── forge acp ──────── Speak the Agent Client Protocol
  ├── forge session ──── Save/resume agent state
  └── forge infra ────── Terraform workspace provisioning
```

Every action is observable. Every network call is sandboxable. Every model is reachable. Every agent is controllable. The developer IS the loop.

## WHY IT KILLS EACH COMPETITOR

### OpenAI (Codex, ChatGPT, API)
- **Locked to OpenAI models** → Forge routes to ANY provider
- **No agent orchestration** → Forge runs 10+ agent types concurrently
- **No sandboxing** → Forge jails every operation with httpjail
- **Proprietary protocol** → Forge speaks ACP (open standard)
- **No self-hosting** → Forge runs on your infrastructure

### Anthropic (Claude Code, Console)
- **Locked to Claude** → Forge uses any model natively
- **Single agent** → Forge orchestrates multiple agents
- **No API gateway** → Forge exposes OpenAI + Anthropic compatible endpoints
- **Desktop only** → Forge gives browser IDE + terminal
- **No skills system** → Forge uses open AgentSkills format

### Cursor IDE
- **Closed protocol** → Forge uses ACP (open)
- **Single IDE** → Forge works in VS Code, Neovim, browser
- **No self-hosting** → Forge is self-hosted
- **No multi-agent** → Forge runs agents in parallel
- **Vendor model lock-in** → Forge routes to any model

### vly.ai
- **Proprietary agent loop** → Forge is open source, composable
- **No offline** → Forge works locally
- **No sandboxing** → Forge jails everything
- **SaaS only** → Forge is self-hosted

### Google Labs (Jules, Gemini CLI)
- **Google-only models** → Forge is model-agnostic
- **No security** → Forge sandboxes with httpjail
- **No multi-agent** → Forge orchestrates all agents
- **No dev environments** → Forge provisions with envbuilder

## ARCHITECTURE: THE FORGE RUNTIME

```
                    ┌─────────────────────────────────────────┐
                    │          THE FORGE RUNTIME              │
                    │                                         │
                    │  ┌─────────────────────────────────┐   │
                    │  │   LAYER 7: SURFACE               │   │
                    │  │   forge mux (desktop)            │   │
                    │  │   forge blink (Slack/GitHub)     │   │
                    │  │   forge ide (browser VS Code)    │   │
                    │  │   forge neovim (editor)          │   │
                    │  │   forge tty (terminal)           │   │
                    │  └──────────────┬──────────────────┘   │
                    │                 │                       │
                    │  ┌──────────────┴──────────────────┐   │
                    │  │   LAYER 6: ORCHESTRATION          │   │
                    │  │   forge orchestrate (multi-agent) │   │
                    │  │   forge serve (single agent)      │   │
                    │  │   forge session (state mgmt)      │   │
                    │  │   ACP protocol (agent ↔ editor)   │   │
                    │  └──────────────┬──────────────────┘   │
                    │                 │                       │
                    │  ┌──────────────┴──────────────────┐   │
                    │  │   LAYER 5: INTELLIGENCE           │   │
                    │  │   internal/router (LLM gateway)   │   │
                    │  │   Anthropic/OpenAI/Google/xAI     │   │
                    │  │   Streaming SSE + Data Stream     │   │
                    │  │   Token counting (ai-tokenizer)    │   │
                    │  │   internal/vector (HNSW search)   │   │
                    │  │   internal/agentsmd (instructions) │   │
                    │  │   internal/skills (capabilities)   │   │
                    │  └──────────────┬──────────────────┘   │
                    │                 │                       │
                    │  ┌──────────────┴──────────────────┐   │
                    │  │   LAYER 4: SECURITY               │   │
                    │  │   forge jail (httpjail network)   │   │
                    │  │   internal/sandbox (envbox)       │   │
                    │  │   internal/reaper (process mgmt)  │   │
                    │  └──────────────┬──────────────────┘   │
                    │                 │                       │
                    │  ┌──────────────┴──────────────────┐   │
                    │  │   LAYER 3: TRANSPORT              │   │
                    │  │   internal/ws (WebSocket)         │   │
                    │  │   internal/mux (yamux streams)    │   │
                    │  │   internal/kcp (reliable UDP)     │   │
                    │  │   forge transfer (wush P2P)       │   │
                    │  └──────────────┬──────────────────┘   │
                    │                 │                       │
                    │  ┌──────────────┴──────────────────┐   │
                    │  │   LAYER 2: INFRASTRUCTURE         │   │
                    │  │   forge env (envbuilder)          │   │
                    │  │   forge infra (Terraform)         │   │
                    │  │   internal/cache (redjet Redis)   │   │
                    │  │   internal/clock (quartz)         │   │
                    │  │   internal/git (guts AST)         │   │
                    │  │   internal/log (slog structured)  │   │
                    │  └──────────────┬──────────────────┘   │
                    │                 │                       │
                    │  ┌──────────────┴──────────────────┐   │
                    │  │   LAYER 1: CORE                   │   │
                    │  │   Go runtime (single binary)      │   │
                    │  │   Cobra CLI (12+ commands)        │   │
                    │  │   HTTP API (unified gateway)      │   │
                    │  │   SSE streaming (all providers)   │   │
                    │  └─────────────────────────────────┘   │
                    │                                         │
                    └─────────────────────────────────────────┘
```

## THE KILL SHOT

Every competitor is a walled garden. The Forge is the open weapon that makes ALL gardens interchangeable.

- OpenAI changes their API? Swap to Anthropic. One config change.
- Cursor shuts down? Use VS Code + forge, or Neovim + forge.
- Google raises prices? Route to xAI. One flag.
- vly.ai goes down? You self-host. Your infra. Your rules.

The singleton form: the developer controls the model, the agent, the protocol, the security, the infrastructure. Everything is composable. Everything is observable. Everything is replaceable.
