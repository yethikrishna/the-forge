module github.com/forge/sword

go 1.25.0

require (
	github.com/google/renameio v1.0.1
	github.com/spf13/cobra v1.10.2
	github.com/viterin/vek v0.4.3
	golang.org/x/sys v0.44.0
)

require (
	github.com/chewxy/math32 v1.10.1 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/spf13/pflag v1.0.9 // indirect
	github.com/viterin/partial v1.1.0 // indirect
	golang.org/x/exp v0.0.0-20230817173708-d852ddb80c63 // indirect
)
