# Quick Start

## Install

### macOS (Apple Silicon)
```bash
curl -fsSL https://github.com/yethikrishna/the-forge/releases/download/v3.0.0-alpha/forge-darwin-arm64.gz | gunzip > forge
chmod +x forge
sudo mv forge /usr/local/bin/
```

### macOS (Intel)
```bash
curl -fsSL https://github.com/yethikrishna/the-forge/releases/download/v3.0.0-alpha/forge-darwin-amd64.gz | gunzip > forge
chmod +x forge
sudo mv forge /usr/local/bin/
```

### Linux (x86_64)
```bash
curl -fsSL https://github.com/yethikrishna/the-forge/releases/download/v3.0.0-alpha/forge-linux-amd64.gz | gunzip > forge
chmod +x forge
sudo mv forge /usr/local/bin/
```

### Linux (ARM64)
```bash
curl -fsSL https://github.com/yethikrishna/the-forge/releases/download/v3.0.0-alpha/forge-linux-arm64.gz | gunzip > forge
chmod +x forge
sudo mv forge /usr/local/bin/
```

### From Source (requires Go 1.25+)
```bash
git clone https://github.com/yethikrishna/the-forge.git
cd the-forge
make build
```

## First Run

```bash
# See the architecture
forge version

# Chat with any LLM
forge chat -m openai/gpt-4o-mini
forge chat -m anthropic/claude-sonnet-4
forge chat -m google/gemini-2.5-pro
forge chat -m xai/grok-3

# Serve an agent
forge serve -- claude
forge serve --port 8080 -- codex

# Run multiple agents
forge mux --agents claude:3284,codex:3285,aider:3286

# Sandbox an agent
forge jail --allow github.com -- claude

# Compare model pricing
forge cost
forge cost --provider openai --json
```

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `ANTHROPIC_API_KEY` | Anthropic (Claude) |
| `OPENAI_API_KEY` | OpenAI (GPT, o-series) |
| `GOOGLE_API_KEY` | Google (Gemini) |
| `XAI_API_KEY` | xAI (Grok) |
| `DEEPSEEK_API_KEY` | DeepSeek |
| `AZURE_OPENAI_API_KEY` | Azure OpenAI |
| `OPENROUTER_API_KEY` | OpenRouter |

## Docker

```bash
docker build -t forge .
docker run -e ANTHROPIC_API_KEY=sk-... forge serve -- claude
```

## Kubernetes

```bash
helm install forge ./helm/ \
  --set secrets.anthropicApiKey=sk-... \
  --set forge.agentCommand=claude
```
