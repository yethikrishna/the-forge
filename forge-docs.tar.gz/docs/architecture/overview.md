# Architecture

The Forge is a 7-layer platform. Each layer builds on the one below.

```
┌─────────────────────────────────────────────────────┐
│  L7 Surface        mux blink ide neovim tty desktop │
├─────────────────────────────────────────────────────┤
│  L6 Orchestration   serve orchestrate session acp    │
├─────────────────────────────────────────────────────┤
│  L5 Intelligence    router aibridge vector agentsmd  │
├─────────────────────────────────────────────────────┤
│  L4 Security        jail boundary sandbox reaper     │
├─────────────────────────────────────────────────────┤
│  L3 Transport       ws yamux wgtunnel wush           │
├─────────────────────────────────────────────────────┤
│  L2 Infrastructure  env envbuilder codersdk tailnet  │
├─────────────────────────────────────────────────────┤
│  L1 Core            Go runtime Cobra CLI HTTP API SSE│
└─────────────────────────────────────────────────────┘
```

## L1 — Core

The foundation. Go runtime, Cobra CLI framework, HTTP server, SSE streaming.

**Packages:** `cmd/`, `internal/version`, `internal/clock`, `internal/log`

## L2 — Infrastructure

Environment management, SDKs, networking primitives.

**Packages:** `internal/envbuilder`, `internal/codersdk`, `internal/tailnet`, `internal/pty`, `internal/provisionerd`, `internal/quartz`, `internal/slog`

## L3 — Transport

Network protocols, multiplexing, tunnels, file transfer.

**Packages:** `internal/websocket`, `internal/yamux`, `internal/wgtunnel`, `internal/wush`, `internal/ssh`

## L4 — Security

Process isolation, network sandboxing, resource management.

**Packages:** `internal/boundary`, `internal/sandbox`, `internal/reaper`, `internal/exectrace`, `internal/clistat`

## L5 — Intelligence

LLM routing, AI interception, vector search, agent instructions.

**Packages:** `internal/router`, `internal/aibridge`, `internal/hnsw`, `internal/vector`, `internal/aisdk`, `internal/aicommit`, `internal/agentsmd`

## L6 — Orchestration

Agent serving, session management, protocol handling.

**Packages:** `internal/agentapi`, `internal/acp`, `internal/session`, `internal/coder-agent`

## L7 — Surface

User-facing interfaces: desktop, terminal, IDE, bot platform.

**Packages:** `internal/desktop`, `internal/tui`, `internal/web`, `internal/marketplace`

---

## Data Flow

```
User → forge CLI → L7 (Surface)
                    ↓
              L6 (Orchestration) → agentapi / ACP
                    ↓
              L5 (Intelligence) → router → LLM Provider
                    ↓
              L4 (Security) → jail (optional)
                    ↓
              L3 (Transport) → WebSocket / HTTP
                    ↓
              L2 (Infrastructure) → envbuilder / tailnet
                    ↓
              L1 (Core) → Go runtime
```

## Model Router

The router speaks 7 providers natively:

| Provider | Protocol | Streaming |
|----------|----------|-----------|
| Anthropic | Native Messages API | SSE |
| OpenAI | Chat Completions | SSE |
| Google | GenerateContent | SSE |
| xAI | OpenAI-compatible | SSE |
| DeepSeek | OpenAI-compatible | SSE |
| Azure | Azure OpenAI | SSE |
| OpenRouter | OpenAI-compatible | SSE |

Cost tracking is automatic — every response includes token usage and cost.

## ACP Integration

The Forge implements the full Agent Client Protocol v0.13 via `coder/acp-go-sdk`:

- **Initialize** — capability negotiation
- **Sessions** — create, load, resume, close, list
- **Prompt** — with streaming updates
- **Permissions** — tool call authorization
- **NES** — non-edit suggestions
- **Experimental** — document tracking, provider management
