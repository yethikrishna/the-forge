# Commands Reference

## forge serve

Start the unified agent orchestration server.

```bash
forge serve -- claude                          # Launch Claude agent
forge serve --port 8080 -- codex               # Custom port + Codex
forge serve --acp -- claude                    # ACP transport
forge serve --jail --jail-rule github.com -- claude  # Network sandbox
forge serve -s session.json -- claude          # Persistent state
forge serve -I "Fix the bug in main.go" -- claude  # Initial prompt
```

| Flag | Default | Description |
|------|---------|-------------|
| `--port, -p` | 3284 | Server port |
| `--type, -t` | auto | Override agent type |
| `--model, -m` | anthropic/claude-sonnet-4 | Model (provider/model) |
| `--acp` | false | Use ACP transport |
| `--jail, -j` | false | Enable httpjail sandbox |
| `--prompt, -I` | | Initial prompt |
| `--state-file, -s` | | Session state file |

## forge chat

Interactive LLM chat with any provider.

```bash
forge chat                                    # Default model
forge chat -m openai/gpt-4o-mini             # Specific model
forge chat -m deepseek/deepseek-r1           # DeepSeek reasoning
```

## forge mux

Run multiple agents in parallel (tmux split-pane).

```bash
forge mux 3                                    # 3 Claude instances
forge mux --agents claude:3284,codex:3285      # Named agents
forge mux 2 --layout tiled                     # Layout option
```

## forge acp

Agent Client Protocol server (native ACP Go SDK v0.13).

```bash
forge acp                                      # Start as ACP agent
forge acp --mode agent                         # Explicit mode
```

Implements the full ACP Agent interface: Initialize, Sessions, Prompt, Streaming, Permissions, NES.

## forge jail

Network sandbox for agent processes.

```bash
forge jail -- claude                           # Block all network
forge jail --allow github.com -- claude         # Allow github.com only
forge jail --allow github.com --allow api.anthropic.com -- claude
```

## forge transfer

P2P encrypted file transfer via WireGuard.

```bash
forge transfer send file.tar.gz                # Send a file
forge transfer receive                         # Receive files
```

## forge env

Dev environments from Dockerfiles.

```bash
forge env                                      # Use ./Dockerfile
forge env -f dev.Dockerfile                    # Specific Dockerfile
forge env -f Dockerfile -- bash                # Override command
```

## forge blink

Self-hosted AI agent bot platform.

```bash
forge blink                                    # Start platform
forge blink --platform slack                   # Slack bot
forge blink --port 9090                        # Custom port
```

## forge desktop

Portable Linux desktop for AI agents.

```bash
forge desktop                                  # Start desktop
forge desktop --resolution 1920x1080           # Custom resolution
```

## forge commit

AI-powered git commits.

```bash
forge commit                                   # Generate + commit
forge commit --dry-run                         # Preview only
forge commit "fix: auth bug"                   # Custom prefix
```

## forge cost

LLM pricing comparison across providers.

```bash
forge cost                                     # All models
forge cost --provider openai                   # Filter provider
forge cost --json                              # JSON output
```

## forge api

Unified LLM gateway (OpenAI + Anthropic compatible).

```bash
forge api --port 8080                          # Start gateway
```

## forge orchestrate

Multi-agent orchestration.

```bash
forge orchestrate --agents claude:3284,codex:3285
```

## forge session

Persistent conversation sessions.

```bash
forge session list
forge session create
forge session resume <id>
```

## forge index

RAG codebase indexing and search.

```bash
forge index .                                  # Index current directory
forge index . --query "authentication"         # Search
```

## forge version

Display architecture diagram.

```bash
forge version
```
