# Community

## Get Help

- **GitHub Issues:** https://github.com/yethikrishna/the-forge/issues
- **Discussions:** https://github.com/yethikrishna/the-forge/discussions

## Contributing

1. Fork the repo
2. Create a feature branch (`git checkout -b feature/my-feature`)
3. Commit your changes (`git commit -m 'feat: add my feature'`)
4. Push to the branch (`git push origin feature/my-feature`)
5. Open a Pull Request

## The Forgemasters

Top contributors get merge access + swag. Details coming soon.

## Forge Friday

Weekly community showcase — show what you built with The Forge. Details coming soon.

## License

MIT — use it however you want.
