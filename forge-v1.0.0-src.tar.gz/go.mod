module github.com/forge/sword

go 1.25.0

require (
	github.com/google/renameio v1.0.1
	github.com/klauspost/reedsolomon v1.14.0
	github.com/pkg/errors v0.9.1
	github.com/spf13/cobra v1.10.2
	github.com/templexxx/xor v0.0.0-20191217153810-f85b25db303b
	github.com/tjfoc/gmsm v1.4.1
	github.com/viterin/vek v0.4.3
	golang.org/x/crypto v0.51.0
	golang.org/x/net v0.54.0
	golang.org/x/sys v0.44.0
)

require (
	github.com/chewxy/math32 v1.10.1 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/klauspost/cpuid/v2 v2.3.0 // indirect
	github.com/spf13/pflag v1.0.9 // indirect
	github.com/templexxx/cpufeat v0.0.0-20180724012125-cef66df7f161 // indirect
	github.com/viterin/partial v1.1.0 // indirect
	golang.org/x/exp v0.0.0-20230817173708-d852ddb80c63 // indirect
)
