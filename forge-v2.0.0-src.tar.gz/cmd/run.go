package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"

	"github.com/forge/sword/internal/router"
	"github.com/spf13/cobra"
)

type ForgeTask struct {
	Name    string   `json:"name"`
	Agent   string   `json:"agent"`
	Model   string   `json:"model"`
	Prompt  string   `json:"prompt"`
	Files   []string `json:"files"`
	Depends []string `json:"depends"`
	Jail    bool     `json:"jail"`
	Timeout int      `json:"timeout"`
	Output  string   `json:"output"` // Save output to file
}

func runTaskCmd() *cobra.Command {
	var forgefile string
	var listOnly bool
	var dryRun bool

	cmd := &cobra.Command{
		Use:   "run [task]",
		Short: "Execute agent tasks from a Forgefile (Makefile for AI agents)",
		Long: `Execute agent tasks from a Forgefile with dependency ordering.

Tasks run through the Forge model router — no external proxy needed.
Each task gets file contents injected into the prompt automatically.

Example forge.json:
  {
    "tasks": [
      {"name": "review", "model": "anthropic/claude-sonnet-4-20250514",
       "prompt": "Review this code for bugs", "files": ["src/main.go"], "jail": true},
      {"name": "test", "model": "openai/gpt-5-mini",
       "prompt": "Write unit tests", "depends": ["review"]},
      {"name": "commit", "prompt": "Commit the changes", "depends": ["test"]}
    ]
  }`,
		Args: cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx, cancel := context.WithCancel(cmd.Context())
			defer cancel()
			sigChan := make(chan os.Signal, 1)
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
			go func() { <-sigChan; cancel() }()

			ffPath := forgefile
			if ffPath == "" {
				for _, c := range []string{"forge.json", "Forgefile", "Forgefile.json", ".forge.json"} {
					if _, err := os.Stat(c); err == nil {
						ffPath = c
						break
					}
				}
			}
			if ffPath == "" {
				return fmt.Errorf("no Forgefile found. Create forge.json or use -f")
			}

			data, err := os.ReadFile(ffPath)
			if err != nil {
				return fmt.Errorf("read %s: %w", ffPath, err)
			}

			var forge struct {
				Tasks []ForgeTask `json:"tasks"`
			}
			if err := json.Unmarshal(data, &forge); err != nil {
				return fmt.Errorf("parse %s: %w", ffPath, err)
			}

			if len(forge.Tasks) == 0 {
				return fmt.Errorf("no tasks in %s", ffPath)
			}

			if listOnly {
				fmt.Printf("Tasks in %s:\n\n", ffPath)
				for _, t := range forge.Tasks {
					jail := ""
					if t.Jail {
						jail = " [jailed]"
					}
					deps := ""
					if len(t.Depends) > 0 {
						deps = fmt.Sprintf(" <- %s", strings.Join(t.Depends, ","))
					}
					model := t.Model
					if model == "" {
						model = "(default)"
					}
					fmt.Printf("  %-15s %-35s%s%s\n", t.Name, model, deps, jail)
					if t.Prompt != "" {
						fmt.Printf("    %s\n", truncateStr(t.Prompt, 80))
					}
				}
				return nil
			}

			// Initialize model router
			mr := router.NewModelRouter()
			registered := mr.AutoRegister()

			targetTask := ""
			if len(args) > 0 {
				targetTask = args[0]
			}

			order, err := topoSort(forge.Tasks, targetTask)
			if err != nil {
				return err
			}

			fmt.Printf("Forge: Running %d task(s) | %d provider(s) loaded\n\n", len(order), registered)

			for i, taskName := range order {
				select {
				case <-ctx.Done():
					return ctx.Err()
				default:
				}

				var task *ForgeTask
				for j := range forge.Tasks {
					if forge.Tasks[j].Name == taskName {
						task = &forge.Tasks[j]
						break
					}
				}
				if task == nil {
					continue
				}

				model := task.Model
				if model == "" {
					model = "anthropic/claude-sonnet-4-20250514"
				}

				fmt.Printf("[%d/%d] %s\n", i+1, len(order), task.Name)
				fmt.Printf("  Model: %s\n", model)

				// Build prompt with file contents
				prompt := task.Prompt
				for _, f := range task.Files {
					content, err := os.ReadFile(f)
					if err != nil {
						fmt.Printf("  Warning: can't read %s: %v\n", f, err)
						continue
					}
					rel, _ := filepath.Rel(".", f)
					prompt += fmt.Sprintf("\n\n--- %s ---\n%s", rel, string(content))
				}

				if dryRun {
					fmt.Printf("  Prompt: %s...\n", truncateStr(prompt, 120))
					fmt.Printf("  (dry run — not executing)\n\n")
					continue
				}

				if registered == 0 {
					return fmt.Errorf("no API keys set. Set ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_API_KEY, or XAI_API_KEY")
				}

				// Execute via model router
				fmt.Printf("  Executing...\n")
				msgs := []router.Message{{Role: "user", Content: prompt}}

				resp, err := mr.Chat(ctx, router.ChatRequest{Model: model, Messages: msgs})
				if err != nil {
					fmt.Printf("  ERROR: %v\n\n", err)
					continue
				}

				fmt.Printf("  Response (%d tokens):\n", resp.Usage.TotalTokens)
				// Print response with indentation
				lines := strings.Split(resp.Content, "\n")
				for _, line := range lines {
					fmt.Printf("    %s\n", line)
				}

				// Save to file if output specified
				if task.Output != "" {
					if err := os.WriteFile(task.Output, []byte(resp.Content), 0o644); err != nil {
						fmt.Printf("  Warning: couldn't save to %s: %v\n", task.Output, err)
					} else {
						fmt.Printf("  Saved to: %s\n", task.Output)
					}
				}

				fmt.Println()
			}

			fmt.Println("Forge: All tasks complete.")
			return nil
		},
	}

	cmd.Flags().StringVarP(&forgefile, "forgefile", "f", "", "Path to Forgefile")
	cmd.Flags().BoolVarP(&listOnly, "list", "l", false, "List tasks without running")
	cmd.Flags().BoolVarP(&dryRun, "dry-run", "", false, "Show what would run without executing")
	return cmd
}

func topoSort(tasks []ForgeTask, target string) ([]string, error) {
	taskMap := make(map[string]*ForgeTask)
	for i := range tasks {
		taskMap[tasks[i].Name] = &tasks[i]
	}
	visited := make(map[string]bool)
	var order []string
	var visit func(string) error
	visit = func(name string) error {
		if visited[name] {
			return nil
		}
		visited[name] = true
		t, ok := taskMap[name]
		if !ok {
			return fmt.Errorf("task %q not found", name)
		}
		for _, dep := range t.Depends {
			if err := visit(dep); err != nil {
				return err
			}
		}
		order = append(order, name)
		return nil
	}
	if target != "" {
		return order, visit(target)
	}
	for _, t := range tasks {
		if err := visit(t.Name); err != nil {
			return nil, err
		}
	}
	return order, nil
}

func truncateStr(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}
