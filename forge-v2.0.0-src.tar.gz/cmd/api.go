package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/forge/sword/internal/router"
	"github.com/forge/sword/internal/web"
	"github.com/spf13/cobra"
)

var totalTokens atomic.Int64
var totalRequests atomic.Int64

// Cost per 1M tokens (approximate)
var tokenCosts = map[string]float64{
	"anthropic/claude-sonnet-4-20250514": 3.0,  // $3/1M input
	"anthropic/claude-opus-4-20250514":   15.0, // $15/1M input
	"openai/gpt-5-mini":                  1.5,  // $1.50/1M input
	"openai/o3":                          10.0, // $10/1M input
	"google/gemini-2.5-pro":              1.25, // $1.25/1M input
	"google/gemini-2.5-flash":            0.15, // $0.15/1M input
	"xai/grok-4-1-fast":                  3.0,  // $3/1M input
}

func apiCmd() *cobra.Command {
	var port int
	var verbose bool

	cmd := &cobra.Command{
		Use:   "api",
		Short: "Start the Forge API server — unified LLM gateway with web UI",
		Long: `Start an HTTP API server with a built-in web chat UI.

Provides:
  - OpenAI-compatible API:   POST /v1/chat/completions
  - Anthropic-compatible API: POST /v1/messages
  - Web chat UI:              GET /
  - Model list:               GET /v1/models
  - Cost tracking:            GET /v1/usage
  - Health check:             GET /health`,
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx, cancel := context.WithCancel(cmd.Context())
			defer cancel()

			mr := router.NewModelRouter()
			registered := mr.AutoRegister()
			if registered == 0 {
				return fmt.Errorf("no API keys found. Set one of:\n  ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_API_KEY, XAI_API_KEY")
			}

			fmt.Printf("Forge API v1.1.0 | Port %d | %d provider(s) loaded\n", port, registered)

			mux := http.NewServeMux()

			// Web chat UI
			mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
				if r.URL.Path != "/" {
					http.NotFound(w, r)
					return
				}
				w.Header().Set("Content-Type", "text/html; charset=utf-8")
				w.Write([]byte(web.ChatHTML))
			})

			// Health
			mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(map[string]any{
					"status":     "ok",
					"providers":  registered,
					"version":    forgeVersion,
					"uptime":     time.Since(time.Now()).String(),
					"tokens":     totalTokens.Load(),
					"requests":   totalRequests.Load(),
				})
			})

			// Usage / cost tracking
			mux.HandleFunc("/v1/usage", func(w http.ResponseWriter, r *http.Request) {
				tokens := totalTokens.Load()
				requests := totalRequests.Load()
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(map[string]any{
					"total_tokens":   tokens,
					"total_requests": requests,
					"estimated_cost": fmt.Sprintf("$%.4f", float64(tokens)/1_000_000*3.0),
				})
			})

			// Models
			mux.HandleFunc("/v1/models", func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				type model struct {
					ID      string `json:"id"`
					Object  string `json:"object"`
					Created int64  `json:"created"`
					OwnedBy string `json:"owned_by"`
					Cost    string `json:"cost_per_1m_tokens"`
				}
				models := []model{
					{"anthropic/claude-sonnet-4-20250514", "model", 1700000000, "anthropic", "$3.00"},
					{"anthropic/claude-opus-4-20250514", "model", 1700000000, "anthropic", "$15.00"},
					{"anthropic/claude-haiku-3-20250414", "model", 1700000000, "anthropic", "$0.25"},
					{"openai/gpt-5-mini", "model", 1700000000, "openai", "$1.50"},
					{"openai/gpt-5", "model", 1700000000, "openai", "$10.00"},
					{"openai/o3", "model", 1700000000, "openai", "$10.00"},
					{"openai/o4-mini", "model", 1700000000, "openai", "$1.50"},
					{"google/gemini-2.5-pro", "model", 1700000000, "google", "$1.25"},
					{"google/gemini-2.5-flash", "model", 1700000000, "google", "$0.15"},
					{"xai/grok-4-1-fast", "model", 1700000000, "xai", "$3.00"},
				}
				json.NewEncoder(w).Encode(map[string]any{"object": "list", "data": models})
			})

			// OpenAI-compatible chat completions
			mux.HandleFunc("/v1/chat/completions", func(w http.ResponseWriter, r *http.Request) {
				if r.Method != "POST" {
					http.Error(w, "POST only", http.StatusMethodNotAllowed)
					return
				}

				var req struct {
					Model    string `json:"model"`
					Messages []struct {
						Role    string `json:"role"`
						Content string `json:"content"`
					} `json:"messages"`
					Stream bool `json:"stream"`
					MaxTokens int `json:"max_tokens"`
				}
				if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
					http.Error(w, err.Error(), http.StatusBadRequest)
					return
				}

				msgs := make([]router.Message, len(req.Messages))
				for i, m := range req.Messages {
					msgs[i] = router.Message{Role: m.Role, Content: m.Content}
				}

				totalRequests.Add(1)

				if req.Stream {
					w.Header().Set("Content-Type", "text/event-stream")
					w.Header().Set("Cache-Control", "no-cache")
					w.Header().Set("Connection", "keep-alive")
					w.Header().Set("X-Accel-Buffering", "no")

					ch, err := mr.ChatStream(r.Context(), router.ChatRequest{Model: req.Model, Messages: msgs, Stream: true})
					if err != nil {
						fmt.Fprintf(w, "data: {\"error\":{\"message\":\"%s\"}}\n\n", err.Error())
						return
					}

					flusher, _ := w.(http.Flusher)
					var tokenCount int64
					for chunk := range ch {
						if chunk.Done {
							totalTokens.Add(tokenCount)
							fmt.Fprintf(w, "data: {\"id\":\"forge-%d\",\"object\":\"chat.completion.chunk\",\"model\":\"%s\",\"choices\":[{\"index\":0,\"delta\":{},\"finish_reason\":\"stop\"}],\"usage\":{\"prompt_tokens\":0,\"completion_tokens\":%d,\"total_tokens\":%d}}\n\n", time.Now().UnixNano(), chunk.Model, tokenCount, tokenCount)
							fmt.Fprintf(w, "data: [DONE]\n\n")
							flusher.Flush()
							break
						}
						tokenCount++
						data, _ := json.Marshal(map[string]any{
							"id":      fmt.Sprintf("forge-%d", time.Now().UnixNano()),
							"object":  "chat.completion.chunk",
							"model":   chunk.Model,
							"choices": []map[string]any{{"index": 0, "delta": map[string]string{"content": chunk.Delta}, "finish_reason": nil}},
						})
						fmt.Fprintf(w, "data: %s\n\n", data)
						flusher.Flush()
					}
					return
				}

				// Non-streaming
				resp, err := mr.Chat(r.Context(), router.ChatRequest{Model: req.Model, Messages: msgs})
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}

				totalTokens.Add(int64(resp.Usage.TotalTokens))

				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(map[string]any{
					"id":      fmt.Sprintf("forge-%d", time.Now().UnixNano()),
					"object":  "chat.completion",
					"model":   resp.Model,
					"choices": []map[string]any{{"index": 0, "message": map[string]string{"role": "assistant", "content": resp.Content}, "finish_reason": "stop"}},
					"usage":   resp.Usage,
				})
			})

			// Anthropic-compatible
			mux.HandleFunc("/v1/messages", func(w http.ResponseWriter, r *http.Request) {
				if r.Method != "POST" {
					http.Error(w, "POST only", http.StatusMethodNotAllowed)
					return
				}

				var req struct {
					Model     string `json:"model"`
					MaxTokens int    `json:"max_tokens"`
					Stream    bool   `json:"stream"`
					Messages  []struct {
						Role    string `json:"role"`
						Content string `json:"content"`
					} `json:"messages"`
				}
				if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
					http.Error(w, err.Error(), http.StatusBadRequest)
					return
				}

				msgs := make([]router.Message, len(req.Messages))
				for i, m := range req.Messages {
					msgs[i] = router.Message{Role: m.Role, Content: m.Content}
				}

				totalRequests.Add(1)

				if req.Stream {
					w.Header().Set("Content-Type", "text/event-stream")
					w.Header().Set("Cache-Control", "no-cache")
					w.Header().Set("Connection", "keep-alive")
					w.Header().Set("X-Accel-Buffering", "no")

					ch, err := mr.ChatStream(r.Context(), router.ChatRequest{Model: req.Model, Messages: msgs, Stream: true})
					if err != nil {
						fmt.Fprintf(w, "event: error\ndata: {\"error\":{\"message\":\"%s\"}}\n\n", err.Error())
						return
					}

					flusher, _ := w.(http.Flusher)
					var tokenCount int64

					fmt.Fprintf(w, "event: message_start\ndata: {\"type\":\"message_start\",\"message\":{\"id\":\"forge-%d\",\"type\":\"message\",\"role\":\"assistant\",\"model\":\"%s\",\"content\":[],\"usage\":{\"input_tokens\":0,\"output_tokens\":0}}}\n\n", time.Now().UnixNano(), req.Model)
					flusher.Flush()

					fmt.Fprintf(w, "event: content_block_start\ndata: {\"type\":\"content_block_start\",\"index\":0,\"content_block\":{\"type\":\"text\",\"text\":\"\"}}\n\n")
					flusher.Flush()

					for chunk := range ch {
						if chunk.Done {
							totalTokens.Add(tokenCount)
							fmt.Fprintf(w, "event: content_block_stop\ndata: {\"type\":\"content_block_stop\",\"index\":0}\n\n")
							fmt.Fprintf(w, "event: message_delta\ndata: {\"type\":\"message_delta\",\"delta\":{\"stop_reason\":\"end_turn\"},\"usage\":{\"output_tokens\":%d}}\n\n", tokenCount)
							fmt.Fprintf(w, "event: message_stop\ndata: {\"type\":\"message_stop\"}\n\n")
							flusher.Flush()
							break
						}
						tokenCount++
						data, _ := json.Marshal(map[string]any{
							"type":  "content_block_delta",
							"index": 0,
							"delta": map[string]string{"type": "text_delta", "text": chunk.Delta},
						})
						fmt.Fprintf(w, "event: content_block_delta\ndata: %s\n\n", data)
						flusher.Flush()
					}
					return
				}

				resp, err := mr.Chat(r.Context(), router.ChatRequest{Model: req.Model, Messages: msgs})
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}

				totalTokens.Add(int64(resp.Usage.TotalTokens))

				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(map[string]any{
					"id":      fmt.Sprintf("forge-%d", time.Now().UnixNano()),
					"type":    "message",
					"role":    "assistant",
					"model":   resp.Model,
					"content": []map[string]any{{"type": "text", "text": resp.Content}},
					"usage":   map[string]any{"input_tokens": resp.Usage.PromptTokens, "output_tokens": resp.Usage.CompletionTokens},
				})
			})

			server := &http.Server{Addr: fmt.Sprintf(":%d", port), Handler: mux}

			go func() {
				fmt.Println()
				fmt.Printf("  Web UI:      http://localhost:%d/\n", port)
				fmt.Printf("  OpenAI API:  http://localhost:%d/v1/chat/completions\n", port)
				fmt.Printf("  Anthropic:   http://localhost:%d/v1/messages\n", port)
				fmt.Printf("  Models:      http://localhost:%d/v1/models\n", port)
				fmt.Printf("  Usage:       http://localhost:%d/v1/usage\n", port)
				fmt.Printf("  Health:      http://localhost:%d/health\n", port)
				fmt.Println()
				fmt.Println("The wielder and the sword are one.")
				if err := server.ListenAndServe(); err != http.ErrServerClosed {
					fmt.Printf("Server error: %v\n", err)
				}
			}()

			sigChan := make(chan os.Signal, 1)
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
			select {
			case <-sigChan:
				fmt.Println("\nShutting down...")
			case <-ctx.Done():
			}
			server.Shutdown(context.Background())
			return nil
		},
	}

	cmd.Flags().IntVarP(&port, "port", "p", 8080, "Server port")
	cmd.Flags().BoolVarP(&verbose, "verbose", "v", false, "Verbose logging")
	return cmd
}
