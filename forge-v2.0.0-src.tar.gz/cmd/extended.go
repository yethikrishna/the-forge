package cmd

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"text/tabwriter"

	"github.com/forge/sword/internal/rag"
	"github.com/forge/sword/internal/session"
	"github.com/spf13/cobra"
)

func sessionCmd() *cobra.Command {
	var storeDir string

	cmd := &cobra.Command{
		Use:   "session",
		Short: "Manage conversation sessions — persist, resume, fork",
		Long: `Save and resume AI conversations with full context.

Sessions persist every message, token count, and cost estimate.
Fork a session to explore different paths without losing the original.

Examples:
  forge session new my-chat -m anthropic/claude-sonnet-4-20250514
  forge session list
  forge session resume my-chat
  forge session fork my-chat explore-alt
  forge session export my-chat
  forge session delete my-chat`,
	}

	var model string
	var showDetail bool

	newCmd := &cobra.Command{
		Use:   "new [name]",
		Short: "Create a new session",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			s := session.NewStore(storeDir)
			sess, err := s.Create(args[0], model)
			if err != nil {
				return err
			}
			fmt.Printf("Created session: %s (%s)\n", sess.Name, sess.ID)
			fmt.Printf("Model: %s\n", sess.Model)
			return nil
		},
	}
	newCmd.Flags().StringVarP(&model, "model", "m", "anthropic/claude-sonnet-4-20250514", "Default model")
	newCmd.Flags().StringVar(&storeDir, "store", ".forge/sessions", "Session store directory")

	listCmd := &cobra.Command{
		Use:   "list",
		Short: "List all sessions",
		RunE: func(cmd *cobra.Command, args []string) error {
			s := session.NewStore(storeDir)
			sessions, err := s.List()
			if err != nil {
				return err
			}
			if len(sessions) == 0 {
				fmt.Println("No sessions found.")
				return nil
			}
			w := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
			fmt.Fprintf(w, "NAME\tID\tMODEL\tMSGS\tTOKENS\tCOST\tUPDATED\n")
			for _, sess := range sessions {
				fmt.Fprintf(w, "%s\t%s\t%s\t%d\t%d\t$%.4f\t%s\n",
					sess.Name, sess.ID[:8], sess.Model, len(sess.Messages),
					sess.Tokens, sess.Cost, sess.Updated.Format("2006-01-02 15:04"))
			}
			w.Flush()
			return nil
		},
	}
	listCmd.Flags().StringVar(&storeDir, "store", ".forge/sessions", "Session store directory")
	listCmd.Flags().BoolVarP(&showDetail, "detail", "d", false, "Show full details")

	resumeCmd := &cobra.Command{
		Use:   "resume [name-or-id]",
		Short: "Resume a session in chat mode",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			s := session.NewStore(storeDir)
			sess, err := s.Load(args[0])
			if err != nil {
				// Try searching by name
				sessions, _ := s.List()
				for _, ss := range sessions {
					if ss.Name == args[0] {
						sess = ss
						err = nil
						break
					}
				}
				if err != nil {
					return fmt.Errorf("session %q not found", args[0])
				}
			}
			fmt.Printf("Resuming: %s (%s)\n", sess.Name, sess.ID)
			fmt.Printf("Messages: %d | Tokens: %d | Cost: $%.4f\n", len(sess.Messages), sess.Tokens, sess.Cost)
			if len(sess.Messages) > 0 {
				fmt.Println("\nRecent context:")
				last := sess.LastN(4)
				for _, m := range last {
					preview := m.Content
					if len(preview) > 100 {
						preview = preview[:100] + "..."
					}
					fmt.Printf("  [%s] %s\n", m.Role, preview)
				}
			}
			fmt.Println("\nUse 'forge chat --session' to continue this conversation.")
			return nil
		},
	}
	resumeCmd.Flags().StringVar(&storeDir, "store", ".forge/sessions", "Session store directory")

	forkCmd := &cobra.Command{
		Use:   "fork [source] [new-name]",
		Short: "Fork a session to explore a different path",
		Args:  cobra.ExactArgs(2),
		RunE: func(cmd *cobra.Command, args []string) error {
			s := session.NewStore(storeDir)
			forked, err := s.Fork(args[0], args[1])
			if err != nil {
				return err
			}
			fmt.Printf("Forked: %s → %s (%s)\n", args[0], forked.Name, forked.ID)
			fmt.Printf("Messages: %d | Tokens: %d\n", len(forked.Messages), forked.Tokens)
			return nil
		},
	}
	forkCmd.Flags().StringVar(&storeDir, "store", ".forge/sessions", "Session store directory")

	exportCmd := &cobra.Command{
		Use:   "export [name-or-id]",
		Short: "Export a session as markdown",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			s := session.NewStore(storeDir)
			sess, err := s.Load(args[0])
			if err != nil {
				return fmt.Errorf("session %q not found", args[0])
			}
			fmt.Println(sess.Export())
			return nil
		},
	}
	exportCmd.Flags().StringVar(&storeDir, "store", ".forge/sessions", "Session store directory")

	deleteCmd := &cobra.Command{
		Use:   "delete [name-or-id]",
		Short: "Delete a session",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			s := session.NewStore(storeDir)
			if err := s.Delete(args[0]); err != nil {
				return err
			}
			fmt.Printf("Deleted session: %s\n", args[0])
			return nil
		},
	}
	deleteCmd.Flags().StringVar(&storeDir, "store", ".forge/sessions", "Session store directory")

	cmd.AddCommand(newCmd, listCmd, resumeCmd, forkCmd, exportCmd, deleteCmd)
	return cmd
}

// indexCmd — codebase indexing and search
func indexCmd() *cobra.Command {
	var dir string
	var maxResults int
	var contextChars int

	cmd := &cobra.Command{
		Use:   "index [query]",
		Short: "Index your codebase and search it with RAG",
		Long: `Build a search index over your codebase, then query it.
Use this to give AI agents context about your code.

Examples:
  forge index build                    # Index current directory
  forge index build -d /path/to/code  # Index a specific directory
  forge index search "auth handler"    # Search the index
  forge index stats                    # Show index statistics
  forge index context "auth handler"   # Build context for LLM injection`,
		Args: cobra.MaximumNArgs(1),
	}

	var indexDir string
	var query string

	buildSub := &cobra.Command{
		Use:   "build",
		Short: "Build the codebase index",
		RunE: func(cmd *cobra.Command, args []string) error {
			root := dir
			if root == "" {
				root = "."
			}
			idx := rag.NewIndex(root)
			count, err := idx.Build()
			if err != nil {
				return err
			}
			stats := idx.Stats()
			fmt.Printf("Indexed %d files (%d chunks, %s total)\n", count, stats["chunks"], fmt.Sprintf("%d bytes", stats["total_bytes"]))
			byLang, _ := stats["by_lang"].(map[string]int)
			_ = byLang
			return nil
		},
	}
	buildSub.Flags().StringVarP(&dir, "dir", "d", "", "Directory to index")

	searchSub := &cobra.Command{
		Use:   "search [query]",
		Short: "Search the codebase index",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			root := dir
			if root == "" {
				root = "."
			}
			idx := rag.NewIndex(root)
			idx.Build()
			results := idx.Search(args[0], maxResults)
			if len(results) == 0 {
				fmt.Println("No results found.")
				return nil
			}
			w := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
			fmt.Fprintf(w, "FILE\tLANG\tSCORE\tLINE\n")
			for _, r := range results {
				fmt.Fprintf(w, "%s\t%s\t%.2f\tL%d\n", r.Path, r.Lang, r.Score, r.StartLine)
			}
			w.Flush()
			fmt.Println()
			for _, r := range results {
				fmt.Printf("--- %s (L%d) ---\n", r.Path, r.StartLine)
				lines := strings.Split(r.Snippet, "\n")
				showMax := 10
				if len(lines) < showMax {
					showMax = len(lines)
				}
				for _, l := range lines[:showMax] {
					fmt.Printf("  %s\n", l)
				}
				fmt.Println()
			}
			return nil
		},
	}
	searchSub.Flags().StringVarP(&dir, "dir", "d", "", "Directory to index")
	searchSub.Flags().IntVarP(&maxResults, "max", "m", 10, "Max results")

	contextSub := &cobra.Command{
		Use:   "context [query]",
		Short: "Build LLM-ready context from search results",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			root := dir
			if root == "" {
				root = "."
			}
			idx := rag.NewIndex(root)
			idx.Build()
			results := idx.Search(args[0], maxResults)
			ctx := idx.Context(results, contextChars)
			fmt.Println(ctx)
			return nil
		},
	}
	contextSub.Flags().StringVarP(&dir, "dir", "d", "", "Directory to index")
	contextSub.Flags().IntVarP(&maxResults, "max", "m", 10, "Max results")
	contextSub.Flags().IntVarP(&contextChars, "chars", "c", 8000, "Max context chars")

	statsSub := &cobra.Command{
		Use:   "stats",
		Short: "Show index statistics",
		RunE: func(cmd *cobra.Command, args []string) error {
			root := dir
			if root == "" {
				root = "."
			}
			idx := rag.NewIndex(root)
			idx.Build()
			stats := idx.Stats()
			data, _ := json.MarshalIndent(stats, "", "  ")
			fmt.Println(string(data))
			return nil
		},
	}
	statsSub.Flags().StringVarP(&dir, "dir", "d", "", "Directory to index")

	cmd.AddCommand(buildSub, searchSub, contextSub, statsSub)

	_ = query
	_ = indexDir
	return cmd
}

// execCmd — run code in a sandbox
func execCmd() *cobra.Command {
	var lang string
	var timeout int

	cmd := &cobra.Command{
		Use:   "exec [code]",
		Short: "Execute code in a sandboxed environment",
		Long: `Run code safely inside the Forge sandbox.
Supports: go, python, node, bash, ruby, rust, c

Examples:
  forge exec -l python 'print("hello from forge")'
  forge exec -l go 'package main; import "fmt"; func main() { fmt.Println("hi") }'
  echo 'console.log(42)' | forge exec -l node -`,
		Args: cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			// This imports sandbox at build time
			fmt.Printf("Sandbox execution for %s (timeout: %ds)\n", lang, timeout)
			fmt.Printf("Code: %s\n", args[0])
			fmt.Println("(full execution wired in forge serve)")
			return nil
		},
	}

	cmd.Flags().StringVarP(&lang, "lang", "l", "python", "Language: go, python, node, bash, ruby, rust, c")
	cmd.Flags().IntVarP(&timeout, "timeout", "t", 30, "Execution timeout in seconds")

	return cmd
}

// watchCmd — file watcher
func watchCmd() *cobra.Command {
	var dir string
	var patterns []string
	var task string

	cmd := &cobra.Command{
		Use:   "watch",
		Short: "Watch files and auto-trigger agent tasks on changes",
		Long: `Monitor files for changes and trigger Forge tasks automatically.

Examples:
  forge watch -d . -p .go,.py --task review`,
		RunE: func(cmd *cobra.Command, args []string) error {
			fmt.Printf("Watching %s for %s changes → task: %s\n", dir, patterns, task)
			fmt.Println("(file watcher runs as a daemon alongside forge serve)")
			return nil
		},
	}

	cmd.Flags().StringVarP(&dir, "dir", "d", ".", "Directory to watch")
	cmd.Flags().StringSliceVarP(&patterns, "pattern", "p", []string{".go"}, "File extensions to watch")
	cmd.Flags().StringVarP(&task, "task", "t", "review", "Forgefile task to trigger")

	return cmd
}

// pluginCmd — manage plugins
func pluginCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "plugin",
		Short: "Manage Forge plugins",
		Long:  `List, install, and manage plugins that extend Forge behavior.`,
	}

	listSub := &cobra.Command{
		Use:   "list",
		Short: "List installed plugins",
		RunE: func(cmd *cobra.Command, args []string) error {
			fmt.Println("No plugins installed. Create .forge/plugins/ and add plugin.json files.")
			return nil
		},
	}

	installSub := &cobra.Command{
		Use:   "install [path]",
		Short: "Install a plugin from a directory or URL",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			fmt.Printf("Installing plugin from: %s\n", args[0])
			fmt.Println("(plugin installation wired through forge serve)")
			return nil
		},
	}

	cmd.AddCommand(listSub, installSub)
	return cmd
}

// muxCmd — parallel agent desktop (future)
func muxCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "mux",
		Short: "Launch parallel agent desktop (experimental)",
		Long: `Run multiple AI agents in parallel, each in its own terminal pane.
Agents can communicate with each other through the Forge message bus.

This is an experimental feature. Requires a terminal with split pane support.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			fmt.Println("Forge Mux — Parallel Agent Desktop")
			fmt.Println()
			fmt.Println("This feature requires a TTY with split-pane support.")
			fmt.Println("Run: forge mux --agents 3 --model anthropic/claude-sonnet-4-20250514")
			fmt.Println()
			fmt.Println("(full implementation in progress)")
			return nil
		},
	}
	return cmd
}

// blinkCmd — self-hosted agent platform (future)
func blinkCmd() *cobra.Command {
	var port int
	cmd := &cobra.Command{
		Use:   "blink",
		Short: "Self-hosted agent platform — Slack/GitHub/Teams bot host",
		Long: `Blink is a self-hosted platform for deploying Forge agents as:
  - Slack bots
  - GitHub bots / Actions
  - Discord bots
  - Telegram bots
  - Teams bots
  - Custom webhooks

All agents share the same model router, session store, and plugin system.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			fmt.Println("Forge Blink — Agent Platform")
			fmt.Println()
			fmt.Printf("Starting on port %d...\n", port)
			fmt.Println("Available surfaces: slack, github, discord, telegram, teams, webhook")
			fmt.Println()
			fmt.Println("(full implementation in progress)")
			return nil
		},
	}
	cmd.Flags().IntVarP(&port, "port", "p", 9090, "Platform port")
	return cmd
}
