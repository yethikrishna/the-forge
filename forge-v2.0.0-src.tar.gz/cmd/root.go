package cmd

import (
	"context"

	"github.com/spf13/cobra"
)

var (
	forgeVersion = "1.1.0"
	buildTime    = "unknown"
)

func Execute(ctx context.Context) error {
	root := &cobra.Command{
		Use:   "forge",
		Short: "The Forge - Unified AI Agent Orchestration Platform",
		Long: `The Forge melts down the Coder arsenal into a single mythic sword.

It orchestrates every AI agent through ACP, routes to any model,
jails every operation for security, and provides a unified workspace.

The wielder and the sword are one.`,
		SilenceUsage: true,
	}

	root.AddCommand(
		serveCmd(),
		orchestratorCmd(),
		agentsCmd(),
		modelsCmd(),
		jailCmd(),
		commitCmd(),
		chatCmd(),
		apiCmd(),
		envCmd(),
		acpCmd(),
		agentsmdCmd(),
		runTaskCmd(),
		initCmd(),
		costCmd(),
		sessionCmd(),
		indexCmd(),
		execCmd(),
		watchCmd(),
		pluginCmd(),
		muxCmd(),
		blinkCmd(),
		versionCmd(),
	)
	return root.ExecuteContext(ctx)
}
