package cmd

import (
	"fmt"
	"strings"

	"github.com/spf13/cobra"
)

type modelCost struct {
	ID           string
	Provider     string
	Input1M      float64
	Output1M     float64
	Context      string
}

var modelCosts = []modelCost{
	{"anthropic/claude-opus-4-20250514", "Anthropic", 15.0, 75.0, "200K"},
	{"anthropic/claude-sonnet-4-20250514", "Anthropic", 3.0, 15.0, "200K"},
	{"anthropic/claude-haiku-3-20250414", "Anthropic", 0.25, 1.25, "200K"},
	{"openai/gpt-5", "OpenAI", 10.0, 30.0, "128K"},
	{"openai/gpt-5-mini", "OpenAI", 1.5, 6.0, "128K"},
	{"openai/o3", "OpenAI", 10.0, 40.0, "200K"},
	{"openai/o4-mini", "OpenAI", 1.5, 6.0, "200K"},
	{"google/gemini-2.5-pro", "Google", 1.25, 10.0, "1M"},
	{"google/gemini-2.5-flash", "Google", 0.15, 0.60, "1M"},
	{"xai/grok-4-1-fast", "xAI", 3.0, 15.0, "128K"},
	{"xai/grok-3-mini", "xAI", 0.30, 0.50, "128K"},
}

func costCmd() *cobra.Command {
	var tokens int

	cmd := &cobra.Command{
		Use:   "cost",
		Short: "Compare LLM costs across providers",
		Long:  `Show pricing for all supported models and estimate costs.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			fmt.Println("Forge: LLM Pricing Comparison")
			fmt.Println()
			fmt.Printf("  %-38s %-10s %12s %12s %8s\n", "Model", "Provider", "Input/1M", "Output/1M", "Ctx")
			fmt.Println("  " + strings.Repeat("-", 85))

			for _, m := range modelCosts {
				fmt.Printf("  %-38s %-10s $%10.2f $%10.2f %7s\n", m.ID, m.Provider, m.Input1M, m.Output1M, m.Context)
			}

			if tokens > 0 {
				fmt.Println()
				fmt.Printf("  Estimated cost for %d tokens:\n", tokens)
				fmt.Println()
				for _, m := range modelCosts {
					// Assume 70% input, 30% output
					inputTokens := float64(tokens) * 0.7
					outputTokens := float64(tokens) * 0.3
					cost := (inputTokens/1_000_000)*m.Input1M + (outputTokens/1_000_000)*m.Output1M
					fmt.Printf("  %-38s $%.4f\n", m.ID, cost)
				}
			}

			fmt.Println()
			fmt.Println("  Tip: Use forge api --port 8080 and check /v1/usage for live cost tracking")
			return nil
		},
	}

	cmd.Flags().IntVarP(&tokens, "tokens", "t", 0, "Estimate cost for N tokens")
	return cmd
}
