package rag

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/forge/sword/internal/log"
)

// Document represents an indexed file
type Document struct {
	Path    string   `json:"path"`
	Content string   `json:"content"`
	Lang    string   `json:"lang"`
	Chunks  []Chunk  `json:"chunks"`
	Size    int64    `json:"size"`
	ModTime string   `json:"mod_time"`
}

// Chunk is a segment of a document for retrieval
type Chunk struct {
	Content  string `json:"content"`
	StartLine int   `json:"start_line"`
	EndLine   int   `json:"end_line"`
	Hash     string `json:"hash"`
}

// Index manages document indexing and retrieval
type Index struct {
	root      string
	docs      map[string]*Document
	ignoreDir []string
	extMap    map[string]string
	mu        sync.RWMutex
	logger    *log.Logger
}

var defaultIgnore = []string{".git", "node_modules", "vendor", "__pycache__", ".cache", "dist", "build", "bin", "obj", ".next", ".venv", "venv"}

var langMap = map[string]string{
	".go": "go", ".py": "python", ".js": "javascript", ".ts": "typescript",
	".rs": "rust", ".java": "java", ".rb": "ruby", ".c": "c", ".cpp": "cpp",
	".h": "c", ".hpp": "cpp", ".cs": "csharp", ".swift": "swift", ".kt": "kotlin",
	".scala": "scala", ".sh": "bash", ".sql": "sql", ".html": "html", ".css": "css",
	".md": "markdown", ".json": "json", ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
}

// NewIndex creates a RAG index rooted at dir
func NewIndex(dir string) *Index {
	return &Index{
		root:      dir,
		docs:      make(map[string]*Document),
		ignoreDir: defaultIgnore,
		extMap:    langMap,
		logger:    log.New("rag"),
	}
}

// Build scans the directory and indexes all supported files
func (idx *Index) Build() (int, error) {
	idx.mu.Lock()
	defer idx.mu.Unlock()

	count := 0
	err := filepath.Walk(idx.root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if info.IsDir() {
			for _, ignore := range idx.ignoreDir {
				if info.Name() == ignore {
					return filepath.SkipDir
				}
			}
			return nil
		}

		ext := filepath.Ext(path)
		lang, supported := idx.extMap[ext]
		if !supported {
			return nil
		}

		content, err := os.ReadFile(path)
		if err != nil {
			return nil
		}

		// Skip very large files (>1MB)
		if len(content) > 1_000_000 {
			return nil
		}

		relPath, _ := filepath.Rel(idx.root, path)
		doc := &Document{
			Path:    relPath,
			Content: string(content),
			Lang:    lang,
			Size:    info.Size(),
			ModTime: info.ModTime().Format("2006-01-02T15:04:05"),
		}

		// Chunk the document
		doc.Chunks = chunkContent(string(content), 100, 20) // 100 lines per chunk, 20 line overlap

		idx.docs[relPath] = doc
		count++
		return nil
	})

	idx.logger.InfoMsg("indexed")
	return count, err
}

// Search performs keyword-based retrieval (vector search requires embedding model)
func (idx *Index) Search(query string, maxResults int) []SearchResult {
	idx.mu.RLock()
	defer idx.mu.RUnlock()

	terms := strings.Fields(strings.ToLower(query))
	var results []SearchResult

	for _, doc := range idx.docs {
		score := 0.0
		lower := strings.ToLower(doc.Content)

		for _, term := range terms {
			count := strings.Count(lower, term)
			if count > 0 {
				score += float64(count) * (1.0 / float64(len(terms)))
			}
		}

		if score > 0 {
			// Find best matching chunk
			bestChunk := bestMatchingChunk(doc.Chunks, terms)
			results = append(results, SearchResult{
				Path:      doc.Path,
				Lang:      doc.Lang,
				Score:     score,
				Snippet:   bestChunk.Content,
				StartLine: bestChunk.StartLine,
			})
		}
	}

	// Sort by score descending
	sortResults(results)
	if maxResults > 0 && len(results) > maxResults {
		results = results[:maxResults]
	}

	return results
}

// SearchResult is a ranked search result
type SearchResult struct {
	Path      string  `json:"path"`
	Lang      string  `json:"lang"`
	Score     float64 `json:"score"`
	Snippet   string  `json:"snippet"`
	StartLine int     `json:"start_line"`
}

// Stats returns index statistics
func (idx *Index) Stats() map[string]any {
	idx.mu.RLock()
	defer idx.mu.RUnlock()

	byLang := make(map[string]int)
	totalSize := int64(0)
	totalChunks := 0

	for _, doc := range idx.docs {
		byLang[doc.Lang]++
		totalSize += doc.Size
		totalChunks += len(doc.Chunks)
	}

	return map[string]any{
		"files":        len(idx.docs),
		"chunks":       totalChunks,
		"total_bytes":  totalSize,
		"by_language":  byLang,
	}
}

// Context builds a context window from search results for LLM injection
func (idx *Index) Context(results []SearchResult, maxChars int) string {
	var b strings.Builder
	used := 0

	for _, r := range results {
		entry := fmt.Sprintf("\n--- %s (L%d, score: %.2f) ---\n%s\n", r.Path, r.StartLine, r.Score, r.Snippet)
		if used+len(entry) > maxChars {
			break
		}
		b.WriteString(entry)
		used += len(entry)
	}

	return b.String()
}

func chunkContent(content string, chunkSize, overlap int) []Chunk {
	lines := strings.Split(content, "\n")
	var chunks []Chunk

	i := 0
	for i < len(lines) {
		end := i + chunkSize
		if end > len(lines) {
			end = len(lines)
		}

		chunk := Chunk{
			Content:   strings.Join(lines[i:end], "\n"),
			StartLine: i + 1,
			EndLine:   end,
			Hash:      simpleHash(strings.Join(lines[i:end], "\n")),
		}
		chunks = append(chunks, chunk)

		i += chunkSize - overlap
		if i >= len(lines) {
			break
		}
	}

	return chunks
}

func bestMatchingChunk(chunks []Chunk, terms []string) Chunk {
	best := Chunk{}
	bestScore := 0.0

	for _, c := range chunks {
		lower := strings.ToLower(c.Content)
		score := 0.0
		for _, t := range terms {
			score += float64(strings.Count(lower, t))
		}
		if score > bestScore {
			bestScore = score
			best = c
		}
	}

	if best.Content == "" && len(chunks) > 0 {
		return chunks[0]
	}
	return best
}

func sortResults(results []SearchResult) {
	for i := 0; i < len(results); i++ {
		for j := i + 1; j < len(results); j++ {
			if results[j].Score > results[i].Score {
				results[i], results[j] = results[j], results[i]
			}
		}
	}
}

func simpleHash(s string) string {
	return fmt.Sprintf("%08x", len(s))
}
