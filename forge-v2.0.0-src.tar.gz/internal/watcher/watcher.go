package watcher

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/forge/sword/internal/log"
)

// Event represents a file change
type Event struct {
	Path      string
	Operation string // create, modify, delete
	Extension string
	Timestamp time.Time
}

// Handler is called when a file changes
type Handler func(ctx context.Context, events []Event) error

// Watcher monitors files and triggers handlers
type Watcher struct {
	root      string
	patterns  []string
	interval  time.Duration
	handler   Handler
	debounce  time.Duration
	ignoreDir []string

	mu     sync.Mutex
	state  map[string]os.FileInfo
	events []Event
	stop   chan struct{}
	logger *log.Logger
}

// Config for creating a watcher
type Config struct {
	Root      string
	Patterns  []string // File extensions to watch (e.g., ".go", ".py")
	Interval  time.Duration
	Debounce  time.Duration
	Handler   Handler
	IgnoreDir []string
}

// New creates a file watcher
func New(cfg Config) *Watcher {
	if cfg.Interval == 0 {
		cfg.Interval = 2 * time.Second
	}
	if cfg.Debounce == 0 {
		cfg.Debounce = 5 * time.Second
	}
	if len(cfg.IgnoreDir) == 0 {
		cfg.IgnoreDir = []string{".git", "node_modules", "vendor", "__pycache__", ".cache", "dist", "build"}
	}
	return &Watcher{
		root:      cfg.Root,
		patterns:  cfg.Patterns,
		interval:  cfg.Interval,
		handler:   cfg.Handler,
		debounce:  cfg.Debounce,
		ignoreDir: cfg.IgnoreDir,
		state:     make(map[string]os.FileInfo),
		stop:      make(chan struct{}),
		logger:    log.New("watcher"),
	}
}

// Start begins watching for file changes
func (w *Watcher) Start(ctx context.Context) error {
	// Initial scan
	if err := w.scan(); err != nil {
		return fmt.Errorf("initial scan failed: %w", err)
	}

	w.logger.InfoMsg("watching")

	// Debounce timer
	debounceTimer := time.NewTimer(w.debounce)
	debounceTimer.Stop()

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-w.stop:
			return nil
		case <-time.After(w.interval):
			changed, err := w.detectChanges()
			if err != nil {
				w.logger.WarnMsg("scan error")
				continue
			}
			if len(changed) > 0 {
				w.mu.Lock()
				w.events = append(w.events, changed...)
				w.mu.Unlock()
				debounceTimer.Reset(w.debounce)
			}
		case <-debounceTimer.C:
			w.mu.Lock()
			events := w.events
			w.events = nil
			w.mu.Unlock()

			if len(events) > 0 && w.handler != nil {
				w.logger.InfoMsg("triggering handler")
				if err := w.handler(ctx, events); err != nil {
					w.logger.WarnMsg("handler error")
				}
			}
		}
	}
}

// Stop the watcher
func (w *Watcher) Stop() {
	close(w.stop)
}

func (w *Watcher) scan() error {
	return filepath.Walk(w.root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if info.IsDir() {
			for _, ignore := range w.ignoreDir {
				if info.Name() == ignore {
					return filepath.SkipDir
				}
			}
			return nil
		}
		if w.matchPattern(path) {
			w.state[path] = info
		}
		return nil
	})
}

func (w *Watcher) detectChanges() ([]Event, error) {
	current := make(map[string]os.FileInfo)
	var events []Event

	filepath.Walk(w.root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if info.IsDir() {
			for _, ignore := range w.ignoreDir {
				if info.Name() == ignore {
					return filepath.SkipDir
				}
			}
			return nil
		}
		if !w.matchPattern(path) {
			return nil
		}
		current[path] = info

		prev, existed := w.state[path]
		if !existed {
			events = append(events, Event{Path: path, Operation: "create", Extension: filepath.Ext(path), Timestamp: time.Now()})
		} else if info.ModTime().After(prev.ModTime()) {
			events = append(events, Event{Path: path, Operation: "modify", Extension: filepath.Ext(path), Timestamp: time.Now()})
		}
		return nil
	})

	// Detect deletions
	for path := range w.state {
		if _, exists := current[path]; !exists {
			events = append(events, Event{Path: path, Operation: "delete", Extension: filepath.Ext(path), Timestamp: time.Now()})
		}
	}

	w.state = current
	return events, nil
}

func (w *Watcher) matchPattern(path string) bool {
	if len(w.patterns) == 0 {
		return true
	}
	ext := filepath.Ext(path)
	for _, p := range w.patterns {
		if strings.EqualFold(ext, p) || strings.HasSuffix(path, p) {
			return true
		}
	}
	return false
}
