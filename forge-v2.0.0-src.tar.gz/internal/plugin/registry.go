package plugin

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

// Plugin is a loaded plugin definition
type Plugin struct {
	Name        string            `json:"name"`
	Version     string            `json:"version"`
	Description string            `json:"description"`
	Command     string            `json:"command"`   // Executable to run
	Args        []string          `json:"args"`      // Args to pass
	Env         map[string]string `json:"env"`       // Env vars
	Hooks       []Hook            `json:"hooks"`     // When to trigger
	Models      []string          `json:"models"`    // Which models this plugin works with
	Author      string            `json:"author"`
	Homepage    string            `json:"homepage"`
}

// Hook defines when a plugin triggers
type Hook struct {
	Event  string `json:"event"`  // pre-chat, post-chat, pre-run, post-run, on-file-change, on-error
	Filter string `json:"filter"` // Optional: only trigger if this condition matches
}

// Result from plugin execution
type Result struct {
	Success  bool   `json:"success"`
	Output   string `json:"output"`
	Error    string `json:"error,omitempty"`
	Modified bool   `json:"modified"` // Did the plugin modify the request/response?
}

// Registry manages plugins
type Registry struct {
	dir     string
	plugins map[string]*Plugin
}

// NewRegistry creates a plugin registry
func NewRegistry(dir string) *Registry {
	return &Registry{
		dir:     dir,
		plugins: make(map[string]*Plugin),
	}
}

// Load reads all plugins from the registry directory
func (r *Registry) Load() (int, error) {
	entries, err := os.ReadDir(r.dir)
	if err != nil {
		if os.IsNotExist(err) {
			return 0, nil
		}
		return 0, err
	}

	count := 0
	for _, e := range entries {
		if e.IsDir() {
			// Check for plugin.json in directory
			pluginPath := filepath.Join(r.dir, e.Name(), "plugin.json")
			if _, err := os.Stat(pluginPath); err == nil {
				p, err := r.loadPlugin(pluginPath)
				if err == nil {
					r.plugins[p.Name] = p
					count++
				}
			}
		} else if strings.HasSuffix(e.Name(), ".json") {
			p, err := r.loadPlugin(filepath.Join(r.dir, e.Name()))
			if err == nil {
				r.plugins[p.Name] = p
				count++
			}
		}
	}

	return count, nil
}

// Get returns a plugin by name
func (r *Registry) Get(name string) (*Plugin, bool) {
	p, ok := r.plugins[name]
	return p, ok
}

// List returns all loaded plugins
func (r *Registry) List() []*Plugin {
	list := make([]*Plugin, 0, len(r.plugins))
	for _, p := range r.plugins {
		list = append(list, p)
	}
	return list
}

// Execute runs a plugin
func (r *Registry) Execute(name string, input map[string]any) (*Result, error) {
	p, ok := r.plugins[name]
	if !ok {
		return nil, fmt.Errorf("plugin %q not found", name)
	}

	inputJSON, _ := json.Marshal(input)

	cmd := exec.Command(p.Command, p.Args...)
	cmd.Stdin = strings.NewReader(string(inputJSON))
	cmd.Env = os.Environ()
	for k, v := range p.Env {
		cmd.Env = append(cmd.Env, fmt.Sprintf("%s=%s", k, v))
	}

	output, err := cmd.Output()
	result := &Result{
		Success: err == nil,
		Output:  string(output),
	}

	if err != nil {
		result.Error = err.Error()
		if exitErr, ok := err.(*exec.ExitError); ok {
			result.Error = string(exitErr.Stderr)
		}
	}

	return result, nil
}

// HooksFor returns plugins that match a given hook event
func (r *Registry) HooksFor(event string) []*Plugin {
	var matching []*Plugin
	for _, p := range r.plugins {
		for _, h := range p.Hooks {
			if h.Event == event {
				matching = append(matching, p)
				break
			}
		}
	}
	return matching
}

func (r *Registry) loadPlugin(path string) (*Plugin, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var p Plugin
	if err := json.Unmarshal(data, &p); err != nil {
		return nil, fmt.Errorf("parse %s: %w", path, err)
	}
	if p.Name == "" {
		return nil, fmt.Errorf("plugin at %s has no name", path)
	}
	return &p, nil
}
