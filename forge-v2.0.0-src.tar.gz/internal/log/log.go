package log

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sync"
	"time"
)

type Level int

const (
	Debug Level = iota
	Info
	Warn
	Error
)

func (l Level) String() string {
	switch l {
	case Debug:
		return "DEBUG"
	case Info:
		return "INFO"
	case Warn:
		return "WARN"
	case Error:
		return "ERROR"
	default:
		return "UNKNOWN"
	}
}

type Entry struct {
	Level   Level                  `json:"level"`
	Time    time.Time              `json:"time"`
	Message string                 `json:"msg"`
	Fields  map[string]interface{} `json:"fields,omitempty"`
}

type Logger struct {
	mu     sync.Mutex
	output io.Writer
	level  Level
	fields map[string]interface{}
}

func New(component string) *Logger {
	l := &Logger{
		output: os.Stderr,
		level:  Info,
		fields: make(map[string]interface{}),
	}
	l.fields["component"] = component
	return l
}

func (l *Logger) WithField(key string, value interface{}) *Logger {
	l.mu.Lock()
	defer l.mu.Unlock()
	newFields := make(map[string]interface{}, len(l.fields)+1)
	for k, v := range l.fields {
		newFields[k] = v
	}
	newFields[key] = value
	return &Logger{output: l.output, level: l.level, fields: newFields}
}

func (l *Logger) WithFields(fields map[string]interface{}) *Logger {
	l.mu.Lock()
	defer l.mu.Unlock()
	newFields := make(map[string]interface{}, len(l.fields)+len(fields))
	for k, v := range l.fields {
		newFields[k] = v
	}
	for k, v := range fields {
		newFields[k] = v
	}
	return &Logger{output: l.output, level: l.level, fields: newFields}
}

func (l *Logger) SetLevel(level Level) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.level = level
}

func (l *Logger) SetOutput(w io.Writer) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.output = w
}

func (l *Logger) log(level Level, msg string, fields map[string]interface{}) {
	if level < l.level {
		return
	}
	entry := Entry{
		Level:   level,
		Time:    time.Now().UTC(),
		Message: msg,
		Fields:  fields,
	}

	l.mu.Lock()
	defer l.mu.Unlock()

	data, _ := json.Marshal(entry)
	fmt.Fprintln(l.output, string(data))
}

func (l *Logger) DebugMsg(msg string)                  { l.log(Debug, msg, nil) }
func (l *Logger) InfoMsg(msg string)                   { l.log(Info, msg, nil) }
func (l *Logger) WarnMsg(msg string)                   { l.log(Warn, msg, nil) }
func (l *Logger) ErrorMsg(msg string)                  { l.log(Error, msg, nil) }
func (l *Logger) Debugf(format string, args ...any) { l.log(Debug, fmt.Sprintf(format, args...), nil) }
func (l *Logger) Infof(format string, args ...any)  { l.log(Info, fmt.Sprintf(format, args...), nil) }
func (l *Logger) Warnf(format string, args ...any)  { l.log(Warn, fmt.Sprintf(format, args...), nil) }
func (l *Logger) Errorf(format string, args ...any) { l.log(Error, fmt.Sprintf(format, args...), nil) }

var Default = New("forge")

// Package-level convenience functions use short names
func LogDebug(msg string)                  { Default.DebugMsg(msg) }
func LogInfo(msg string)                   { Default.InfoMsg(msg) }
func LogWarn(msg string)                   { Default.WarnMsg(msg) }
func LogError(msg string)                  { Default.ErrorMsg(msg) }
func Debugf(format string, args ...any) { Default.Debugf(format, args...) }
func Infof(format string, args ...any)  { Default.Infof(format, args...) }
func Warnf(format string, args ...any)  { Default.Warnf(format, args...) }
func Errorf(format string, args ...any) { Default.Errorf(format, args...) }
