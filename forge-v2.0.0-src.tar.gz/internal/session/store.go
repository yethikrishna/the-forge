package session

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// Message is a single chat message in a session
type Message struct {
	Role      string    `json:"role"`
	Content   string    `json:"content"`
	Model     string    `json:"model"`
	Tokens    int       `json:"tokens"`
	Timestamp time.Time `json:"timestamp"`
}

// Session is a persisted conversation
type Session struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	Model     string    `json:"model"`
	Created   time.Time `json:"created"`
	Updated   time.Time `json:"updated"`
	Messages  []Message `json:"messages"`
	Tokens    int       `json:"total_tokens"`
	Cost      float64   `json:"estimated_cost"`
	Tags      []string  `json:"tags"`
	ParentID  string    `json:"parent_id,omitempty"` // Fork from another session
}

// Store manages sessions on disk
type Store struct {
	dir string
}

// NewStore creates a session store at the given directory
func NewStore(dir string) *Store {
	return &Store{dir: dir}
}

// Dir returns the store directory
func (s *Store) Dir() string { return s.dir }

// Create starts a new session
func (s *Store) Create(name, model string) (*Session, error) {
	os.MkdirAll(s.dir, 0o755)

	id := generateID(name)
	sess := &Session{
		ID:      id,
		Name:    name,
		Model:   model,
		Created: time.Now(),
		Updated: time.Now(),
	}
	if err := s.Save(sess); err != nil {
		return nil, err
	}
	return sess, nil
}

// Load reads a session by ID
func (s *Store) Load(id string) (*Session, error) {
	data, err := os.ReadFile(filepath.Join(s.dir, id+".json"))
	if err != nil {
		return nil, fmt.Errorf("session %s not found", id)
	}
	var sess Session
	if err := json.Unmarshal(data, &sess); err != nil {
		return nil, fmt.Errorf("corrupt session: %w", err)
	}
	return &sess, nil
}

// Save writes a session to disk
func (s *Store) Save(sess *Session) error {
	sess.Updated = time.Now()
	data, err := json.MarshalIndent(sess, "", "  ")
	if err != nil {
		return err
	}
	os.MkdirAll(s.dir, 0o755)
	return os.WriteFile(filepath.Join(s.dir, sess.ID+".json"), data, 0o644)
}

// Delete removes a session
func (s *Store) Delete(id string) error {
	return os.Remove(filepath.Join(s.dir, id+".json"))
}

// List returns all sessions sorted by most recent
func (s *Store) List() ([]*Session, error) {
	entries, err := os.ReadDir(s.dir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}

	var sessions []*Session
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		id := strings.TrimSuffix(e.Name(), ".json")
		sess, err := s.Load(id)
		if err != nil {
			continue
		}
		sessions = append(sessions, sess)
	}

	sort.Slice(sessions, func(i, j int) bool {
		return sessions[i].Updated.After(sessions[j].Updated)
	})

	return sessions, nil
}

// Fork creates a copy of a session with a new ID
func (s *Store) Fork(id string, newName string) (*Session, error) {
	orig, err := s.Load(id)
	if err != nil {
		return nil, err
	}
	forked := &Session{
		ID:       generateID(newName),
		Name:     newName,
		Model:    orig.Model,
		Created:  time.Now(),
		Updated:  time.Now(),
		Messages: orig.Messages,
		Tokens:   orig.Tokens,
		Cost:     orig.Cost,
		ParentID: orig.ID,
	}
	if err := s.Save(forked); err != nil {
		return nil, err
	}
	return forked, nil
}

// AddMessage appends a message and updates token/cost counters
func (s *Session) AddMessage(role, content, model string, tokens int) {
	msg := Message{
		Role:      role,
		Content:   content,
		Model:     model,
		Tokens:    tokens,
		Timestamp: time.Now(),
	}
	s.Messages = append(s.Messages, msg)
	s.Tokens += tokens
	// Rough cost estimate: $3/1M tokens average
	s.Cost += float64(tokens) / 1_000_000 * 3.0
	s.Updated = time.Now()
}

// LastN returns the last N messages for context window
func (s *Session) LastN(n int) []Message {
	if n >= len(s.Messages) {
		return s.Messages
	}
	return s.Messages[len(s.Messages)-n:]
}

// Export returns the session as markdown
func (s *Session) Export() string {
	var b strings.Builder
	b.WriteString(fmt.Sprintf("# Session: %s\n", s.Name))
	b.WriteString(fmt.Sprintf("ID: %s | Model: %s | Tokens: %d | Cost: $%.4f\n", s.ID, s.Model, s.Tokens, s.Cost))
	b.WriteString(fmt.Sprintf("Created: %s | Updated: %s\n\n", s.Created.Format(time.RFC3339), s.Updated.Format(time.RFC3339)))

	for _, msg := range s.Messages {
		b.WriteString(fmt.Sprintf("## %s (%s)\n", strings.Title(msg.Role), msg.Timestamp.Format("15:04:05")))
		if msg.Model != "" {
			b.WriteString(fmt.Sprintf("Model: %s | Tokens: %d\n\n", msg.Model, msg.Tokens))
		}
		b.WriteString(msg.Content + "\n\n---\n\n")
	}
	return b.String()
}

func generateID(name string) string {
	h := sha256.Sum256([]byte(name + time.Now().String()))
	return fmt.Sprintf("%x", h[:8])
}
