package sandbox

import (
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// Lang defines a supported execution language
type Lang struct {
	Name    string
	Ext     string
	Command string
	Args    []string // {file} is replaced with the temp file path
	Timeout time.Duration
}

var languages = map[string]Lang{
	"go":    {"Go", ".go", "go", []string{"run", "{file}"}, 30 * time.Second},
	"python": {"Python", ".py", "python3", []string{"{file}"}, 30 * time.Second},
	"node":   {"JavaScript", ".js", "node", []string{"{file}"}, 15 * time.Second},
	"bash":   {"Bash", ".sh", "bash", []string{"{file}"}, 15 * time.Second},
	"ruby":   {"Ruby", ".rb", "ruby", []string{"{file}"}, 15 * time.Second},
	"rust":   {"Rust", ".rs", "rustc", []string{"-o", "{out}", "{file}"}, 60 * time.Second},
	"c":      {"C", ".c", "gcc", []string{"-o", "{out}", "{file}"}, 30 * time.Second},
}

// Result holds execution output
type Result struct {
	ExitCode  int
	Stdout    string
	Stderr    string
	Duration  time.Duration
	Language  string
	Truncated bool
}

// Exec runs code in a sandboxed environment
func Exec(ctx context.Context, lang, code string) (*Result, error) {
	l, ok := languages[lang]
	if !ok {
		supported := make([]string, 0, len(languages))
		for k := range languages {
			supported = append(supported, k)
		}
		return nil, fmt.Errorf("unsupported language %q. Supported: %s", lang, strings.Join(supported, ", "))
	}

	// Write code to temp file
	tmpDir, err := os.MkdirTemp("", "forge-sandbox-*")
	if err != nil {
		return nil, fmt.Errorf("create temp dir: %w", err)
	}
	defer os.RemoveAll(tmpDir)

	tmpFile := filepath.Join(tmpDir, "code"+l.Ext)
	if err := os.WriteFile(tmpFile, []byte(code), 0o644); err != nil {
		return nil, fmt.Errorf("write temp file: %w", err)
	}

	// Build command args
	args := make([]string, len(l.Args))
	for i, a := range l.Args {
		a = strings.ReplaceAll(a, "{file}", tmpFile)
		a = strings.ReplaceAll(a, "{out}", filepath.Join(tmpDir, "out"))
		args[i] = a
	}

	// Execute with timeout
	ctx, cancel := context.WithTimeout(ctx, l.Timeout)
	defer cancel()

	start := time.Now()
	cmd := exec.CommandContext(ctx, l.Command, args...)
	cmd.Dir = tmpDir

	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	err = cmd.Run()
	duration := time.Since(start)

	result := &Result{
		ExitCode: 0,
		Stdout:   stdout.String(),
		Stderr:   stderr.String(),
		Duration: duration,
		Language: l.Name,
	}

	if err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			result.ExitCode = exitErr.ExitCode()
		} else if ctx.Err() == context.DeadlineExceeded {
			result.ExitCode = -1
			result.Stderr = "Execution timed out"
		} else {
			return nil, fmt.Errorf("execution error: %w", err)
		}
	}

	// Truncate large outputs
	const maxOutput = 64 * 1024 // 64KB
	if len(result.Stdout) > maxOutput {
		result.Stdout = result.Stdout[:maxOutput] + "\n... (truncated)"
		result.Truncated = true
	}
	if len(result.Stderr) > maxOutput {
		result.Stderr = result.Stderr[:maxOutput] + "\n... (truncated)"
		result.Truncated = true
	}

	return result, nil
}

// Languages returns the list of supported languages
func Languages() []string {
	supported := make([]string, 0, len(languages))
	for k := range languages {
		supported = append(supported, k)
	}
	return supported
}
